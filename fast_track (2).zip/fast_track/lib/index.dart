// Export pages
export '/other/pages/home_page/home_page_widget.dart' show HomePageWidget;
export '/other/pages/ride/ride_widget.dart' show RideWidget;
export '/other/pages/create_race/create_race_widget.dart' show CreateRaceWidget;
export '/other/pages/privacy_policy/privacy_policy_widget.dart'
    show PrivacyPolicyWidget;
export '/other/pages/term_of_service/term_of_service_widget.dart'
    show TermOfServiceWidget;
export '/other/pages/my_rides/my_rides_widget.dart' show MyRidesWidget;
export '/other/pages/my_victories/my_victories_widget.dart'
    show MyVictoriesWidget;
export '/other/pages/settings/settings_widget.dart' show SettingsWidget;
export '/other/pages/specification/specification_widget.dart'
    show SpecificationWidget;
export '/signup/signup_widget.dart' show SignupWidget;
export '/login/login_widget.dart' show LoginWidget;
export '/forgot_password/forgot_password_widget.dart' show ForgotPasswordWidget;
export '/victory_info/victory_info_widget.dart' show VictoryInfoWidget;
export '/edit_profile/edit_profile_widget.dart' show EditProfileWidget;
export '/races/races_widget.dart' show RacesWidget;
export '/other/pages/edit_specification/edit_specification_widget.dart'
    show EditSpecificationWidget;
export '/other/pages/profile/profile_widget.dart' show ProfileWidget;
export '/find_track/find_track_widget.dart' show FindTrackWidget;
export '/other/pages/social_feed/social_feed_widget.dart' show SocialFeedWidget;
export '/new_post/new_post_widget.dart' show NewPostWidget;
export '/other/pages/my_profile/my_profile_widget.dart' show MyProfileWidget;
export '/create_profile/create_profile_widget.dart' show CreateProfileWidget;
