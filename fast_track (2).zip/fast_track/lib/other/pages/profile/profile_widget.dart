import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_expanded_image_view.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/index.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'package:simple_gradient_text/simple_gradient_text.dart';
import 'profile_model.dart';
export 'profile_model.dart';

class ProfileWidget extends StatefulWidget {
  const ProfileWidget({
    super.key,
    required this.profileUser,
  });

  /// current user profile
  final UserRecord? profileUser;

  static String routeName = 'Profile';
  static String routePath = '/profile';

  @override
  State<ProfileWidget> createState() => _ProfileWidgetState();
}

class _ProfileWidgetState extends State<ProfileWidget>
    with TickerProviderStateMixin {
  late ProfileModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ProfileModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderWidth: 1.0,
            buttonSize: 60.0,
            fillColor: FlutterFlowTheme.of(context).secondaryBackground,
            icon: Icon(
              Icons.arrow_back_rounded,
              color: FlutterFlowTheme.of(context).primaryText,
              size: 30.0,
            ),
            onPressed: () async {
              context.safePop();
            },
          ),
          actions: [],
          centerTitle: false,
          elevation: 0.0,
        ),
        body: Align(
          alignment: AlignmentDirectional(0.0, 0.0),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        AuthUserStreamWidget(
                          builder: (context) => Text(
                            valueOrDefault<String>(
                              (currentUserDocument?.followers?.toList() ?? [])
                                  .length
                                  .toString(),
                              '5K',
                            ),
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  font: GoogleFonts.inter(
                                    fontWeight: FontWeight.bold,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .fontStyle,
                                  ),
                                  fontSize: 30.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.bold,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .fontStyle,
                                ),
                          ),
                        ),
                        Text(
                          'Followers',
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    font: GoogleFonts.inter(
                                      fontWeight: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .fontWeight,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .fontStyle,
                                    ),
                                    letterSpacing: 0.0,
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .fontStyle,
                                  ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                    child: Container(
                      width: 100.0,
                      height: 100.0,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            FlutterFlowTheme.of(context).primary,
                            FlutterFlowTheme.of(context).tertiary
                          ],
                          stops: [0.0, 1.0],
                          begin: AlignmentDirectional(1.0, -1.0),
                          end: AlignmentDirectional(-1.0, 1.0),
                        ),
                        shape: BoxShape.circle,
                      ),
                      child: Align(
                        alignment: AlignmentDirectional(0.0, 0.0),
                        child: Padding(
                          padding: EdgeInsets.all(4.0),
                          child: Container(
                            width: 100.0,
                            height: 100.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                              shape: BoxShape.circle,
                            ),
                            child: Padding(
                              padding: EdgeInsets.all(4.0),
                              child: InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  await Navigator.push(
                                    context,
                                    PageTransition(
                                      type: PageTransitionType.fade,
                                      child: FlutterFlowExpandedImageView(
                                        image: CachedNetworkImage(
                                          fadeInDuration:
                                              Duration(milliseconds: 500),
                                          fadeOutDuration:
                                              Duration(milliseconds: 500),
                                          imageUrl: valueOrDefault<String>(
                                            widget!.profileUser?.photoUrl,
                                            'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJQAAACUCAMAAABC4vDmAAAAY1BMVEX///8AAADR0dHl5eX29vbi4uLw8PCqqqp0dHTt7e3a2tr8/Pw/Pz+UlJTz8/NlZWWEhIQxMTE6OjpcXFyOjo4ODg5GRkbFxcVUVFSwsLAcHBwhISFLS0u8vLyioqIXFxcpKSkQ0Ih2AAAHbElEQVR4nO1c2baiOhRUBhkUAVFx1v//ytuezk4CZKhA8LjW7XrrPhKKZGfPyWLxD/9nrFdhnOcBQ57H4Wr9q4TiNimq8lg/lxzP+lhWRdLGv0Joe05v9WWpwaW+peftRwnFQVXr6Mio98GHZiy6V0eE0V8cq3s0N6N1VtUHnNIbh7rK5hT9bVu6ESKU7WzylTTjKP3QSuZgFN13inc9680pLc5tHmZRlIV5ey7S00bWERw778K1bm+Dt7yafdJmql9nbbJvroMHbq1X2YrTvnQf0jZXEuLE8lbxkD8NET16Y2/SHHsyTzc9Yg9Pa9h25fuQ3h220vaedgWsaX1wenQHrXLHb43yqjPAdfo+jE/ygLti1OxHRWfnNhMlK5Bt3KsYPVpcyJuxDqZwSuSlK8MpQ4WyMbicR48TycLQTPq6NwJ5w1Qjd+EqlbZc4cF4bQuJVboaM0Qk6fDN5Gn6i2AjxjyNmKtMPH9I/VB6Q9LyG6NFUHISquDg08CvE8Hq5MgqEvP0BE0KilyaK6cVXIl5aiYpAhVCMfjJQdojse9K54W3IxMqK8WdmWrMQw5YC1YV+kwyWcXZIKllcBcF3Laks0VHEZ+rC6QCY26DyxkjI7GCNWLl+d5onGR8vd06fYNQhI39x9z1feK6IDtXadk0ZVqd8T0ecn1lFauWBOqA6sws6eQVNmd0grkWvVo85IjcC9S2ZI9BqmOXgNPFLU5j3lB88UAbHChzHTfMqVhzHf0w/Szmi4CNuldR+nkLJvTcwhp2IKd+gD51nWooLVFNHfCF0X9ES4tcQENWGkIOrMgXPWhlnfuaDeL7ro2cwA/b0sa66WT9TuNBi3c2czJ8vAy+gHfNDyhiLJHR1hZOf7QvMsyCpmqn/jM5By9IlRuEnACJVUhRqlIx8uWFhCF42UnVkFEgWS9VgtzSPEKxuVZDyTDqREJMUqOQQe5LQBMVAhOFBlF8qoa6KqORIMcu0NDoAVq/iH49/ATSOpjSs+gowt5psMGrI2bswSgPqoKgJjRn7lLdX6Q7szCgW45xWi6hwSiiO/QVaKX5fzXsmtOFFDcOvfWLmV+0wTI+mZZFD5i7t2IuzLGrjWg3gb5drGXRA+gak3noGl3aAKBjvkVJgYEjzUl3t7LddMDG8CzoYryOVaYvh7NjvknR+skiTeIPVwNOOhZdnNDxyPDKWWNG9AXnxx5aHh1AFvmNnDkw8lIxPxgP1HOMFPyRGfObbuK/KKeBmao3tlDdtsGDeOYK1cLBbFl/gUPGNdFTGbF6XB4uQqrZG54OVa8MaANwyUlTDkPMC3Ozapfcjy2YWXa3kg0hkyDuYlIEhzkaBKtWcBuOmT9uk1dMamGt8oPY4lPh+uUH7BtL2hshkw/HakerKvRzYLGoAFOVR9p+cX89Qdz1lNwE6g2Sa/JeyB11rgzeta1KT8xZlMA2zoUWndSzex080Eg7mDWTQdaPSAW9fzsgUwal1Yh6Ds0MfQ6RGlUaitNeXPoqR5W/Qw2pkbWhICm5bF3Kx8giaqYhNbrosY3zc1FVxTmPR5eaI9+kfEBHaobSHg7d8nmvgbpAJ+iQSliFov8VQh5DfYJ9lYArz+CxLzfDFjIjLrtT9bB3N/WVJ2hmVtXRkY/Ac1da1qFvZiCDnIMpKT3M7Vx9g4y4LncwI2WEqWLTd10AJw+M82wwFMr7Tp7dHYZiF4iV9hXMHRZRni1wgNNRdujkahA4WEMsoLqAQtegNAyxLMEoUl2AoXFJh8GoJWz3JlFvaPTOMGw3Jzgij6v3Z8+ru42HCQ4SmqtS6yIROo6D0uyrUkHGpFmojVlGQeksq5JmxvRiqBveIylVetGYiP0EKfa3bnmUIiWVUH2AlDplbUruf4CUOrlvKoPMT0pTBjEVjOYnpSkYmUprs5PSltYMRcjZSVEjVT3wAfXl2tlJ6V+tL2zPTcpQ2Na3AMxNytACoG+WmJmUqVlCVDb6UzUzKWNbCfflrj3nYl5SvBdE4/ZqWpXmJWVpVdI1dc1KytrUpWl/m5MU78bXtr+5Ngp6AEm5oYAmeiQ9HUmxIaBZMDXjOzafTgY/N2ZMIoo23Q8cUAfbdN0bmqeAB7mWhuZFS8k6uPV7NODWb4m+Omr0B4cmeaFinU8lucHpOMF3HrxYBDxML7/miIpc3f/AYR64HCsemWcFxxx7+s4DYvJRutO3HKXrHDr0rUWlQ4dHR5HtHM/0KFhTjmfOd5B1KeZphLhGUs+BtyO/0hn3MUd+u4ejlz4OR68K6fKEcYej/R8jl9s9qvFymsiJ4WnnbEP5ZPuEA/eL3tUE1ylXE8illN3EWY87d118xyUOf5B0C8ffcN3FYnAxyDN1OIO5WJ17F6n4uRhkeIXKcpOCQhGkm96jiT9naHjZzBK5bKb/zDP1at1V1/Jcm/2jVb4lbB8fuJZn8ZUXGP0gGXn71BvzXPX0xjdeirX4yuvDfuB80dqH7vKLg71K6gfYfexKOoavu7yPELJrDi8ym2O5LxK1/vochhdC/i6ff/ht/AeTm1/dJrEzIwAAAABJRU5ErkJggg==',
                                          ),
                                          fit: BoxFit.contain,
                                        ),
                                        allowRotation: false,
                                        tag: valueOrDefault<String>(
                                          widget!.profileUser?.photoUrl,
                                          'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJQAAACUCAMAAABC4vDmAAAAY1BMVEX///8AAADR0dHl5eX29vbi4uLw8PCqqqp0dHTt7e3a2tr8/Pw/Pz+UlJTz8/NlZWWEhIQxMTE6OjpcXFyOjo4ODg5GRkbFxcVUVFSwsLAcHBwhISFLS0u8vLyioqIXFxcpKSkQ0Ih2AAAHbElEQVR4nO1c2baiOhRUBhkUAVFx1v//ytuezk4CZKhA8LjW7XrrPhKKZGfPyWLxD/9nrFdhnOcBQ57H4Wr9q4TiNimq8lg/lxzP+lhWRdLGv0Joe05v9WWpwaW+peftRwnFQVXr6Mio98GHZiy6V0eE0V8cq3s0N6N1VtUHnNIbh7rK5hT9bVu6ESKU7WzylTTjKP3QSuZgFN13inc9680pLc5tHmZRlIV5ey7S00bWERw778K1bm+Dt7yafdJmql9nbbJvroMHbq1X2YrTvnQf0jZXEuLE8lbxkD8NET16Y2/SHHsyTzc9Yg9Pa9h25fuQ3h220vaedgWsaX1wenQHrXLHb43yqjPAdfo+jE/ygLti1OxHRWfnNhMlK5Bt3KsYPVpcyJuxDqZwSuSlK8MpQ4WyMbicR48TycLQTPq6NwJ5w1Qjd+EqlbZc4cF4bQuJVboaM0Qk6fDN5Gn6i2AjxjyNmKtMPH9I/VB6Q9LyG6NFUHISquDg08CvE8Hq5MgqEvP0BE0KilyaK6cVXIl5aiYpAhVCMfjJQdojse9K54W3IxMqK8WdmWrMQw5YC1YV+kwyWcXZIKllcBcF3Laks0VHEZ+rC6QCY26DyxkjI7GCNWLl+d5onGR8vd06fYNQhI39x9z1feK6IDtXadk0ZVqd8T0ecn1lFauWBOqA6sws6eQVNmd0grkWvVo85IjcC9S2ZI9BqmOXgNPFLU5j3lB88UAbHChzHTfMqVhzHf0w/Szmi4CNuldR+nkLJvTcwhp2IKd+gD51nWooLVFNHfCF0X9ES4tcQENWGkIOrMgXPWhlnfuaDeL7ro2cwA/b0sa66WT9TuNBi3c2czJ8vAy+gHfNDyhiLJHR1hZOf7QvMsyCpmqn/jM5By9IlRuEnACJVUhRqlIx8uWFhCF42UnVkFEgWS9VgtzSPEKxuVZDyTDqREJMUqOQQe5LQBMVAhOFBlF8qoa6KqORIMcu0NDoAVq/iH49/ATSOpjSs+gowt5psMGrI2bswSgPqoKgJjRn7lLdX6Q7szCgW45xWi6hwSiiO/QVaKX5fzXsmtOFFDcOvfWLmV+0wTI+mZZFD5i7t2IuzLGrjWg3gb5drGXRA+gak3noGl3aAKBjvkVJgYEjzUl3t7LddMDG8CzoYryOVaYvh7NjvknR+skiTeIPVwNOOhZdnNDxyPDKWWNG9AXnxx5aHh1AFvmNnDkw8lIxPxgP1HOMFPyRGfObbuK/KKeBmao3tlDdtsGDeOYK1cLBbFl/gUPGNdFTGbF6XB4uQqrZG54OVa8MaANwyUlTDkPMC3Ozapfcjy2YWXa3kg0hkyDuYlIEhzkaBKtWcBuOmT9uk1dMamGt8oPY4lPh+uUH7BtL2hshkw/HakerKvRzYLGoAFOVR9p+cX89Qdz1lNwE6g2Sa/JeyB11rgzeta1KT8xZlMA2zoUWndSzex080Eg7mDWTQdaPSAW9fzsgUwal1Yh6Ds0MfQ6RGlUaitNeXPoqR5W/Qw2pkbWhICm5bF3Kx8giaqYhNbrosY3zc1FVxTmPR5eaI9+kfEBHaobSHg7d8nmvgbpAJ+iQSliFov8VQh5DfYJ9lYArz+CxLzfDFjIjLrtT9bB3N/WVJ2hmVtXRkY/Ac1da1qFvZiCDnIMpKT3M7Vx9g4y4LncwI2WEqWLTd10AJw+M82wwFMr7Tp7dHYZiF4iV9hXMHRZRni1wgNNRdujkahA4WEMsoLqAQtegNAyxLMEoUl2AoXFJh8GoJWz3JlFvaPTOMGw3Jzgij6v3Z8+ru42HCQ4SmqtS6yIROo6D0uyrUkHGpFmojVlGQeksq5JmxvRiqBveIylVetGYiP0EKfa3bnmUIiWVUH2AlDplbUruf4CUOrlvKoPMT0pTBjEVjOYnpSkYmUprs5PSltYMRcjZSVEjVT3wAfXl2tlJ6V+tL2zPTcpQ2Na3AMxNytACoG+WmJmUqVlCVDb6UzUzKWNbCfflrj3nYl5SvBdE4/ZqWpXmJWVpVdI1dc1KytrUpWl/m5MU78bXtr+5Ngp6AEm5oYAmeiQ9HUmxIaBZMDXjOzafTgY/N2ZMIoo23Q8cUAfbdN0bmqeAB7mWhuZFS8k6uPV7NODWb4m+Omr0B4cmeaFinU8lucHpOMF3HrxYBDxML7/miIpc3f/AYR64HCsemWcFxxx7+s4DYvJRutO3HKXrHDr0rUWlQ4dHR5HtHM/0KFhTjmfOd5B1KeZphLhGUs+BtyO/0hn3MUd+u4ejlz4OR68K6fKEcYej/R8jl9s9qvFymsiJ4WnnbEP5ZPuEA/eL3tUE1ylXE8illN3EWY87d118xyUOf5B0C8ffcN3FYnAxyDN1OIO5WJ17F6n4uRhkeIXKcpOCQhGkm96jiT9naHjZzBK5bKb/zDP1at1V1/Jcm/2jVb4lbB8fuJZn8ZUXGP0gGXn71BvzXPX0xjdeirX4yuvDfuB80dqH7vKLg71K6gfYfexKOoavu7yPELJrDi8ym2O5LxK1/vochhdC/i6ff/ht/AeTm1/dJrEzIwAAAABJRU5ErkJggg==',
                                        ),
                                        useHeroAnimation: true,
                                      ),
                                    ),
                                  );
                                },
                                child: Hero(
                                  tag: valueOrDefault<String>(
                                    widget!.profileUser?.photoUrl,
                                    'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJQAAACUCAMAAABC4vDmAAAAY1BMVEX///8AAADR0dHl5eX29vbi4uLw8PCqqqp0dHTt7e3a2tr8/Pw/Pz+UlJTz8/NlZWWEhIQxMTE6OjpcXFyOjo4ODg5GRkbFxcVUVFSwsLAcHBwhISFLS0u8vLyioqIXFxcpKSkQ0Ih2AAAHbElEQVR4nO1c2baiOhRUBhkUAVFx1v//ytuezk4CZKhA8LjW7XrrPhKKZGfPyWLxD/9nrFdhnOcBQ57H4Wr9q4TiNimq8lg/lxzP+lhWRdLGv0Joe05v9WWpwaW+peftRwnFQVXr6Mio98GHZiy6V0eE0V8cq3s0N6N1VtUHnNIbh7rK5hT9bVu6ESKU7WzylTTjKP3QSuZgFN13inc9680pLc5tHmZRlIV5ey7S00bWERw778K1bm+Dt7yafdJmql9nbbJvroMHbq1X2YrTvnQf0jZXEuLE8lbxkD8NET16Y2/SHHsyTzc9Yg9Pa9h25fuQ3h220vaedgWsaX1wenQHrXLHb43yqjPAdfo+jE/ygLti1OxHRWfnNhMlK5Bt3KsYPVpcyJuxDqZwSuSlK8MpQ4WyMbicR48TycLQTPq6NwJ5w1Qjd+EqlbZc4cF4bQuJVboaM0Qk6fDN5Gn6i2AjxjyNmKtMPH9I/VB6Q9LyG6NFUHISquDg08CvE8Hq5MgqEvP0BE0KilyaK6cVXIl5aiYpAhVCMfjJQdojse9K54W3IxMqK8WdmWrMQw5YC1YV+kwyWcXZIKllcBcF3Laks0VHEZ+rC6QCY26DyxkjI7GCNWLl+d5onGR8vd06fYNQhI39x9z1feK6IDtXadk0ZVqd8T0ecn1lFauWBOqA6sws6eQVNmd0grkWvVo85IjcC9S2ZI9BqmOXgNPFLU5j3lB88UAbHChzHTfMqVhzHf0w/Szmi4CNuldR+nkLJvTcwhp2IKd+gD51nWooLVFNHfCF0X9ES4tcQENWGkIOrMgXPWhlnfuaDeL7ro2cwA/b0sa66WT9TuNBi3c2czJ8vAy+gHfNDyhiLJHR1hZOf7QvMsyCpmqn/jM5By9IlRuEnACJVUhRqlIx8uWFhCF42UnVkFEgWS9VgtzSPEKxuVZDyTDqREJMUqOQQe5LQBMVAhOFBlF8qoa6KqORIMcu0NDoAVq/iH49/ATSOpjSs+gowt5psMGrI2bswSgPqoKgJjRn7lLdX6Q7szCgW45xWi6hwSiiO/QVaKX5fzXsmtOFFDcOvfWLmV+0wTI+mZZFD5i7t2IuzLGrjWg3gb5drGXRA+gak3noGl3aAKBjvkVJgYEjzUl3t7LddMDG8CzoYryOVaYvh7NjvknR+skiTeIPVwNOOhZdnNDxyPDKWWNG9AXnxx5aHh1AFvmNnDkw8lIxPxgP1HOMFPyRGfObbuK/KKeBmao3tlDdtsGDeOYK1cLBbFl/gUPGNdFTGbF6XB4uQqrZG54OVa8MaANwyUlTDkPMC3Ozapfcjy2YWXa3kg0hkyDuYlIEhzkaBKtWcBuOmT9uk1dMamGt8oPY4lPh+uUH7BtL2hshkw/HakerKvRzYLGoAFOVR9p+cX89Qdz1lNwE6g2Sa/JeyB11rgzeta1KT8xZlMA2zoUWndSzex080Eg7mDWTQdaPSAW9fzsgUwal1Yh6Ds0MfQ6RGlUaitNeXPoqR5W/Qw2pkbWhICm5bF3Kx8giaqYhNbrosY3zc1FVxTmPR5eaI9+kfEBHaobSHg7d8nmvgbpAJ+iQSliFov8VQh5DfYJ9lYArz+CxLzfDFjIjLrtT9bB3N/WVJ2hmVtXRkY/Ac1da1qFvZiCDnIMpKT3M7Vx9g4y4LncwI2WEqWLTd10AJw+M82wwFMr7Tp7dHYZiF4iV9hXMHRZRni1wgNNRdujkahA4WEMsoLqAQtegNAyxLMEoUl2AoXFJh8GoJWz3JlFvaPTOMGw3Jzgij6v3Z8+ru42HCQ4SmqtS6yIROo6D0uyrUkHGpFmojVlGQeksq5JmxvRiqBveIylVetGYiP0EKfa3bnmUIiWVUH2AlDplbUruf4CUOrlvKoPMT0pTBjEVjOYnpSkYmUprs5PSltYMRcjZSVEjVT3wAfXl2tlJ6V+tL2zPTcpQ2Na3AMxNytACoG+WmJmUqVlCVDb6UzUzKWNbCfflrj3nYl5SvBdE4/ZqWpXmJWVpVdI1dc1KytrUpWl/m5MU78bXtr+5Ngp6AEm5oYAmeiQ9HUmxIaBZMDXjOzafTgY/N2ZMIoo23Q8cUAfbdN0bmqeAB7mWhuZFS8k6uPV7NODWb4m+Omr0B4cmeaFinU8lucHpOMF3HrxYBDxML7/miIpc3f/AYR64HCsemWcFxxx7+s4DYvJRutO3HKXrHDr0rUWlQ4dHR5HtHM/0KFhTjmfOd5B1KeZphLhGUs+BtyO/0hn3MUd+u4ejlz4OR68K6fKEcYej/R8jl9s9qvFymsiJ4WnnbEP5ZPuEA/eL3tUE1ylXE8illN3EWY87d118xyUOf5B0C8ffcN3FYnAxyDN1OIO5WJ17F6n4uRhkeIXKcpOCQhGkm96jiT9naHjZzBK5bKb/zDP1at1V1/Jcm/2jVb4lbB8fuJZn8ZUXGP0gGXn71BvzXPX0xjdeirX4yuvDfuB80dqH7vKLg71K6gfYfexKOoavu7yPELJrDi8ym2O5LxK1/vochhdC/i6ff/ht/AeTm1/dJrEzIwAAAABJRU5ErkJggg==',
                                  ),
                                  transitionOnUserGestures: true,
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(50.0),
                                    child: CachedNetworkImage(
                                      fadeInDuration:
                                          Duration(milliseconds: 500),
                                      fadeOutDuration:
                                          Duration(milliseconds: 500),
                                      imageUrl: valueOrDefault<String>(
                                        widget!.profileUser?.photoUrl,
                                        'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJQAAACUCAMAAABC4vDmAAAAY1BMVEX///8AAADR0dHl5eX29vbi4uLw8PCqqqp0dHTt7e3a2tr8/Pw/Pz+UlJTz8/NlZWWEhIQxMTE6OjpcXFyOjo4ODg5GRkbFxcVUVFSwsLAcHBwhISFLS0u8vLyioqIXFxcpKSkQ0Ih2AAAHbElEQVR4nO1c2baiOhRUBhkUAVFx1v//ytuezk4CZKhA8LjW7XrrPhKKZGfPyWLxD/9nrFdhnOcBQ57H4Wr9q4TiNimq8lg/lxzP+lhWRdLGv0Joe05v9WWpwaW+peftRwnFQVXr6Mio98GHZiy6V0eE0V8cq3s0N6N1VtUHnNIbh7rK5hT9bVu6ESKU7WzylTTjKP3QSuZgFN13inc9680pLc5tHmZRlIV5ey7S00bWERw778K1bm+Dt7yafdJmql9nbbJvroMHbq1X2YrTvnQf0jZXEuLE8lbxkD8NET16Y2/SHHsyTzc9Yg9Pa9h25fuQ3h220vaedgWsaX1wenQHrXLHb43yqjPAdfo+jE/ygLti1OxHRWfnNhMlK5Bt3KsYPVpcyJuxDqZwSuSlK8MpQ4WyMbicR48TycLQTPq6NwJ5w1Qjd+EqlbZc4cF4bQuJVboaM0Qk6fDN5Gn6i2AjxjyNmKtMPH9I/VB6Q9LyG6NFUHISquDg08CvE8Hq5MgqEvP0BE0KilyaK6cVXIl5aiYpAhVCMfjJQdojse9K54W3IxMqK8WdmWrMQw5YC1YV+kwyWcXZIKllcBcF3Laks0VHEZ+rC6QCY26DyxkjI7GCNWLl+d5onGR8vd06fYNQhI39x9z1feK6IDtXadk0ZVqd8T0ecn1lFauWBOqA6sws6eQVNmd0grkWvVo85IjcC9S2ZI9BqmOXgNPFLU5j3lB88UAbHChzHTfMqVhzHf0w/Szmi4CNuldR+nkLJvTcwhp2IKd+gD51nWooLVFNHfCF0X9ES4tcQENWGkIOrMgXPWhlnfuaDeL7ro2cwA/b0sa66WT9TuNBi3c2czJ8vAy+gHfNDyhiLJHR1hZOf7QvMsyCpmqn/jM5By9IlRuEnACJVUhRqlIx8uWFhCF42UnVkFEgWS9VgtzSPEKxuVZDyTDqREJMUqOQQe5LQBMVAhOFBlF8qoa6KqORIMcu0NDoAVq/iH49/ATSOpjSs+gowt5psMGrI2bswSgPqoKgJjRn7lLdX6Q7szCgW45xWi6hwSiiO/QVaKX5fzXsmtOFFDcOvfWLmV+0wTI+mZZFD5i7t2IuzLGrjWg3gb5drGXRA+gak3noGl3aAKBjvkVJgYEjzUl3t7LddMDG8CzoYryOVaYvh7NjvknR+skiTeIPVwNOOhZdnNDxyPDKWWNG9AXnxx5aHh1AFvmNnDkw8lIxPxgP1HOMFPyRGfObbuK/KKeBmao3tlDdtsGDeOYK1cLBbFl/gUPGNdFTGbF6XB4uQqrZG54OVa8MaANwyUlTDkPMC3Ozapfcjy2YWXa3kg0hkyDuYlIEhzkaBKtWcBuOmT9uk1dMamGt8oPY4lPh+uUH7BtL2hshkw/HakerKvRzYLGoAFOVR9p+cX89Qdz1lNwE6g2Sa/JeyB11rgzeta1KT8xZlMA2zoUWndSzex080Eg7mDWTQdaPSAW9fzsgUwal1Yh6Ds0MfQ6RGlUaitNeXPoqR5W/Qw2pkbWhICm5bF3Kx8giaqYhNbrosY3zc1FVxTmPR5eaI9+kfEBHaobSHg7d8nmvgbpAJ+iQSliFov8VQh5DfYJ9lYArz+CxLzfDFjIjLrtT9bB3N/WVJ2hmVtXRkY/Ac1da1qFvZiCDnIMpKT3M7Vx9g4y4LncwI2WEqWLTd10AJw+M82wwFMr7Tp7dHYZiF4iV9hXMHRZRni1wgNNRdujkahA4WEMsoLqAQtegNAyxLMEoUl2AoXFJh8GoJWz3JlFvaPTOMGw3Jzgij6v3Z8+ru42HCQ4SmqtS6yIROo6D0uyrUkHGpFmojVlGQeksq5JmxvRiqBveIylVetGYiP0EKfa3bnmUIiWVUH2AlDplbUruf4CUOrlvKoPMT0pTBjEVjOYnpSkYmUprs5PSltYMRcjZSVEjVT3wAfXl2tlJ6V+tL2zPTcpQ2Na3AMxNytACoG+WmJmUqVlCVDb6UzUzKWNbCfflrj3nYl5SvBdE4/ZqWpXmJWVpVdI1dc1KytrUpWl/m5MU78bXtr+5Ngp6AEm5oYAmeiQ9HUmxIaBZMDXjOzafTgY/N2ZMIoo23Q8cUAfbdN0bmqeAB7mWhuZFS8k6uPV7NODWb4m+Omr0B4cmeaFinU8lucHpOMF3HrxYBDxML7/miIpc3f/AYR64HCsemWcFxxx7+s4DYvJRutO3HKXrHDr0rUWlQ4dHR5HtHM/0KFhTjmfOd5B1KeZphLhGUs+BtyO/0hn3MUd+u4ejlz4OR68K6fKEcYej/R8jl9s9qvFymsiJ4WnnbEP5ZPuEA/eL3tUE1ylXE8illN3EWY87d118xyUOf5B0C8ffcN3FYnAxyDN1OIO5WJ17F6n4uRhkeIXKcpOCQhGkm96jiT9naHjZzBK5bKb/zDP1at1V1/Jcm/2jVb4lbB8fuJZn8ZUXGP0gGXn71BvzXPX0xjdeirX4yuvDfuB80dqH7vKLg71K6gfYfexKOoavu7yPELJrDi8ym2O5LxK1/vochhdC/i6ff/ht/AeTm1/dJrEzIwAAAABJRU5ErkJggg==',
                                      ),
                                      width: 100.0,
                                      height: 100.0,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        AuthUserStreamWidget(
                          builder: (context) => Text(
                            valueOrDefault<String>(
                              (currentUserDocument?.following?.toList() ?? [])
                                  .length
                                  .toString(),
                              '700',
                            ),
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  font: GoogleFonts.inter(
                                    fontWeight: FontWeight.bold,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .fontStyle,
                                  ),
                                  fontSize: 30.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.bold,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .fontStyle,
                                ),
                          ),
                        ),
                        Text(
                          'Following',
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    font: GoogleFonts.inter(
                                      fontWeight: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .fontWeight,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .fontStyle,
                                    ),
                                    letterSpacing: 0.0,
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .fontStyle,
                                  ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 16.0, 0.0, 0.0),
                child: Text(
                  valueOrDefault<String>(
                    widget!.profileUser?.displayName,
                    'Username',
                  ),
                  textAlign: TextAlign.center,
                  style: FlutterFlowTheme.of(context).headlineSmall.override(
                        font: GoogleFonts.interTight(
                          fontWeight: FlutterFlowTheme.of(context)
                              .headlineSmall
                              .fontWeight,
                          fontStyle: FlutterFlowTheme.of(context)
                              .headlineSmall
                              .fontStyle,
                        ),
                        color: FlutterFlowTheme.of(context).primaryText,
                        letterSpacing: 0.0,
                        fontWeight: FlutterFlowTheme.of(context)
                            .headlineSmall
                            .fontWeight,
                        fontStyle: FlutterFlowTheme.of(context)
                            .headlineSmall
                            .fontStyle,
                      ),
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(16.0, 4.0, 16.0, 0.0),
                child: GradientText(
                  valueOrDefault<String>(
                    widget!.profileUser?.email,
                    'recer@gmail.com',
                  ),
                  style: FlutterFlowTheme.of(context).labelSmall.override(
                        font: GoogleFonts.inter(
                          fontWeight: FontWeight.w500,
                          fontStyle:
                              FlutterFlowTheme.of(context).labelSmall.fontStyle,
                        ),
                        color: FlutterFlowTheme.of(context).secondary,
                        fontSize: 14.0,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.w500,
                        fontStyle:
                            FlutterFlowTheme.of(context).labelSmall.fontStyle,
                      ),
                  colors: [
                    FlutterFlowTheme.of(context).primary,
                    FlutterFlowTheme.of(context).tertiary
                  ],
                  gradientDirection: GradientDirection.ltr,
                  gradientType: GradientType.linear,
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(24.0, 12.0, 24.0, 0.0),
                child: Text(
                  valueOrDefault<String>(
                    widget!.profileUser?.city,
                    'Texas',
                  ),
                  textAlign: TextAlign.center,
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        font: GoogleFonts.inter(
                          fontWeight: FlutterFlowTheme.of(context)
                              .bodyMedium
                              .fontWeight,
                          fontStyle:
                              FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                        ),
                        color: FlutterFlowTheme.of(context).secondaryText,
                        letterSpacing: 0.0,
                        fontWeight:
                            FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                        fontStyle:
                            FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                      ),
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                child: AuthUserStreamWidget(
                  builder: (context) => FFButtonWidget(
                    onPressed: () async {
                      await actions.toggleFollow(
                        currentUserUid,
                        widget!.profileUser!.uid,
                      );
                    },
                    text: (currentUserDocument?.following?.toList() ?? [])
                            .contains(valueOrDefault<String>(
                      widget!.profileUser?.uid,
                      'uid',
                    ))
                        ? '\"Unfollow\"'
                        : '\"Follow\"',
                    options: FFButtonOptions(
                      height: 40.0,
                      padding:
                          EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                      iconPadding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                      color: FlutterFlowTheme.of(context).primary,
                      textStyle:
                          FlutterFlowTheme.of(context).titleSmall.override(
                                font: GoogleFonts.interTight(
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .titleSmall
                                      .fontStyle,
                                ),
                                color: Colors.white,
                                letterSpacing: 0.0,
                                fontWeight: FlutterFlowTheme.of(context)
                                    .titleSmall
                                    .fontWeight,
                                fontStyle: FlutterFlowTheme.of(context)
                                    .titleSmall
                                    .fontStyle,
                              ),
                      elevation: 0.0,
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                child: FFButtonWidget(
                  onPressed: () async {
                    context.pushNamed(MyRidesWidget.routeName);
                  },
                  text: 'My Rides',
                  options: FFButtonOptions(
                    height: 40.0,
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    color: FlutterFlowTheme.of(context).primary,
                    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                          font: GoogleFonts.interTight(
                            fontWeight: FlutterFlowTheme.of(context)
                                .titleSmall
                                .fontWeight,
                            fontStyle: FlutterFlowTheme.of(context)
                                .titleSmall
                                .fontStyle,
                          ),
                          color: Colors.white,
                          letterSpacing: 0.0,
                          fontWeight: FlutterFlowTheme.of(context)
                              .titleSmall
                              .fontWeight,
                          fontStyle:
                              FlutterFlowTheme.of(context).titleSmall.fontStyle,
                        ),
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ),
              Expanded(
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 44.0, 0.0, 0.0),
                  child: Container(
                    width: double.infinity,
                    height: 400.0,
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).secondaryBackground,
                      boxShadow: [
                        BoxShadow(
                          blurRadius: 3.0,
                          color: Color(0x33000000),
                          offset: Offset(
                            0.0,
                            -1.0,
                          ),
                        )
                      ],
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(0.0),
                        bottomRight: Radius.circular(0.0),
                        topLeft: Radius.circular(16.0),
                        topRight: Radius.circular(16.0),
                      ),
                    ),
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: EdgeInsets.all(16.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Align(
                                  alignment: AlignmentDirectional(0.0, 0.0),
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 16.0, 0.0, 0.0),
                                    child: Wrap(
                                      spacing: 16.0,
                                      runSpacing: 16.0,
                                      alignment: WrapAlignment.start,
                                      crossAxisAlignment:
                                          WrapCrossAlignment.start,
                                      direction: Axis.horizontal,
                                      runAlignment: WrapAlignment.start,
                                      verticalDirection: VerticalDirection.down,
                                      clipBehavior: Clip.none,
                                      children: [
                                        Container(
                                          width:
                                              MediaQuery.sizeOf(context).width *
                                                  0.4,
                                          height: 160.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .primaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(24.0),
                                          ),
                                          child: Padding(
                                            padding: EdgeInsets.all(12.0),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 12.0, 0.0, 4.0),
                                                  child: Text(
                                                    'Gender',
                                                    textAlign: TextAlign.center,
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .displaySmall
                                                        .override(
                                                          font: GoogleFonts
                                                              .interTight(
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .displaySmall
                                                                    .fontStyle,
                                                          ),
                                                          fontSize: 25.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .displaySmall
                                                                  .fontStyle,
                                                        ),
                                                  ),
                                                ),
                                                Text(
                                                  valueOrDefault<String>(
                                                    widget!.profileUser?.sex
                                                        ?.toString(),
                                                    'Male',
                                                  ),
                                                  textAlign: TextAlign.center,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .labelSmall
                                                      .override(
                                                        font: GoogleFonts.inter(
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontStyle,
                                                        ),
                                                        fontSize: 20.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontWeight,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontStyle,
                                                      ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width:
                                              MediaQuery.sizeOf(context).width *
                                                  0.4,
                                          height: 160.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .primaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(24.0),
                                          ),
                                          child: Padding(
                                            padding: EdgeInsets.all(12.0),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 12.0, 0.0, 4.0),
                                                  child: Text(
                                                    'Rel. Status',
                                                    textAlign: TextAlign.center,
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .displaySmall
                                                        .override(
                                                          font: GoogleFonts
                                                              .interTight(
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .displaySmall
                                                                    .fontStyle,
                                                          ),
                                                          fontSize: 25.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .displaySmall
                                                                  .fontStyle,
                                                        ),
                                                  ),
                                                ),
                                                Text(
                                                  valueOrDefault<String>(
                                                    widget!.profileUser
                                                        ?.relationshipstatus,
                                                    'Single',
                                                  ),
                                                  textAlign: TextAlign.center,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .labelSmall
                                                      .override(
                                                        font: GoogleFonts.inter(
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontStyle,
                                                        ),
                                                        fontSize: 20.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontWeight,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontStyle,
                                                      ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width:
                                              MediaQuery.sizeOf(context).width *
                                                  0.4,
                                          height: 160.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .primaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(24.0),
                                          ),
                                          child: Padding(
                                            padding: EdgeInsets.all(12.0),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 12.0, 0.0, 4.0),
                                                  child: Text(
                                                    'Hometown',
                                                    textAlign: TextAlign.center,
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .displaySmall
                                                        .override(
                                                          font: GoogleFonts
                                                              .interTight(
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .displaySmall
                                                                    .fontStyle,
                                                          ),
                                                          fontSize: 25.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .displaySmall
                                                                  .fontStyle,
                                                        ),
                                                  ),
                                                ),
                                                Text(
                                                  valueOrDefault<String>(
                                                    widget!.profileUser?.city,
                                                    'Texas',
                                                  ),
                                                  textAlign: TextAlign.center,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .labelSmall
                                                      .override(
                                                        font: GoogleFonts.inter(
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontStyle,
                                                        ),
                                                        fontSize: 20.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontWeight,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontStyle,
                                                      ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width:
                                              MediaQuery.sizeOf(context).width *
                                                  0.4,
                                          height: 160.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .primaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(24.0),
                                          ),
                                          child: Padding(
                                            padding: EdgeInsets.all(12.0),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 12.0, 0.0, 4.0),
                                                  child: Text(
                                                    'Age',
                                                    textAlign: TextAlign.center,
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .displaySmall
                                                        .override(
                                                          font: GoogleFonts
                                                              .interTight(
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .displaySmall
                                                                    .fontStyle,
                                                          ),
                                                          fontSize: 25.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .displaySmall
                                                                  .fontStyle,
                                                        ),
                                                  ),
                                                ),
                                                Text(
                                                  valueOrDefault<String>(
                                                    widget!.profileUser?.age
                                                        ?.toString(),
                                                    '20',
                                                  ),
                                                  textAlign: TextAlign.center,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .labelSmall
                                                      .override(
                                                        font: GoogleFonts.inter(
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontStyle,
                                                        ),
                                                        fontSize: 20.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontWeight,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontStyle,
                                                      ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width:
                                              MediaQuery.sizeOf(context).width *
                                                  0.4,
                                          height: 160.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .primaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(24.0),
                                          ),
                                          child: Padding(
                                            padding: EdgeInsets.all(12.0),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 12.0, 0.0, 4.0),
                                                  child: Text(
                                                    'Location',
                                                    textAlign: TextAlign.center,
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .displaySmall
                                                        .override(
                                                          font: GoogleFonts
                                                              .interTight(
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .displaySmall
                                                                    .fontStyle,
                                                          ),
                                                          fontSize: 25.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .displaySmall
                                                                  .fontStyle,
                                                        ),
                                                  ),
                                                ),
                                                Text(
                                                  valueOrDefault<String>(
                                                    widget!.profileUser?.city,
                                                    'Texas',
                                                  ),
                                                  textAlign: TextAlign.center,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .labelSmall
                                                      .override(
                                                        font: GoogleFonts.inter(
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontStyle,
                                                        ),
                                                        fontSize: 20.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontWeight,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontStyle,
                                                      ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width:
                                              MediaQuery.sizeOf(context).width *
                                                  0.4,
                                          height: 160.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .primaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(24.0),
                                          ),
                                          child: Padding(
                                            padding: EdgeInsets.all(12.0),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 12.0, 0.0, 4.0),
                                                  child: Text(
                                                    'Hobbies',
                                                    textAlign: TextAlign.center,
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .displaySmall
                                                        .override(
                                                          font: GoogleFonts
                                                              .interTight(
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .displaySmall
                                                                    .fontStyle,
                                                          ),
                                                          fontSize: 25.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .displaySmall
                                                                  .fontStyle,
                                                        ),
                                                  ),
                                                ),
                                                Text(
                                                  valueOrDefault<String>(
                                                    widget!.profileUser?.hobbies
                                                        ?.take(2)
                                                        .toList()
                                                        ?.firstOrNull,
                                                    'Volleyball',
                                                  ),
                                                  textAlign: TextAlign.center,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .labelSmall
                                                      .override(
                                                        font: GoogleFonts.inter(
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontStyle,
                                                        ),
                                                        fontSize: 20.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontWeight,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontStyle,
                                                      ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width:
                                              MediaQuery.sizeOf(context).width *
                                                  0.4,
                                          height: 160.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .primaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(24.0),
                                          ),
                                          child: Padding(
                                            padding: EdgeInsets.all(12.0),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 12.0, 0.0, 4.0),
                                                  child: Text(
                                                    'Dream Ride',
                                                    textAlign: TextAlign.center,
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .displaySmall
                                                        .override(
                                                          font: GoogleFonts
                                                              .interTight(
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .displaySmall
                                                                    .fontStyle,
                                                          ),
                                                          fontSize: 25.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .displaySmall
                                                                  .fontStyle,
                                                        ),
                                                  ),
                                                ),
                                                Text(
                                                  valueOrDefault<String>(
                                                    widget!
                                                        .profileUser?.dreamRide,
                                                    'Cadillac Sports',
                                                  ),
                                                  textAlign: TextAlign.center,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .labelSmall
                                                      .override(
                                                        font: GoogleFonts.inter(
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontStyle,
                                                        ),
                                                        fontSize: 20.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontWeight,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontStyle,
                                                      ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width:
                                              MediaQuery.sizeOf(context).width *
                                                  0.4,
                                          height: 160.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .primaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(24.0),
                                          ),
                                          child: Padding(
                                            padding: EdgeInsets.all(12.0),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 12.0, 0.0, 4.0),
                                                  child: Text(
                                                    'Fav. Tracks',
                                                    textAlign: TextAlign.center,
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .displaySmall
                                                        .override(
                                                          font: GoogleFonts
                                                              .interTight(
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .displaySmall
                                                                    .fontStyle,
                                                          ),
                                                          fontSize: 25.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .displaySmall
                                                                  .fontStyle,
                                                        ),
                                                  ),
                                                ),
                                                Text(
                                                  valueOrDefault<String>(
                                                    widget!.profileUser
                                                        ?.favouriteTracks
                                                        ?.take(2)
                                                        .toList()
                                                        ?.firstOrNull,
                                                    'Norton',
                                                  ),
                                                  textAlign: TextAlign.center,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .labelSmall
                                                      .override(
                                                        font: GoogleFonts.inter(
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontStyle,
                                                        ),
                                                        fontSize: 20.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontWeight,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontStyle,
                                                      ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width:
                                              MediaQuery.sizeOf(context).width *
                                                  0.4,
                                          height: 160.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .primaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(24.0),
                                          ),
                                          child: Padding(
                                            padding: EdgeInsets.all(12.0),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 12.0, 0.0, 4.0),
                                                  child: Text(
                                                    'Future Mods',
                                                    textAlign: TextAlign.center,
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .displaySmall
                                                        .override(
                                                          font: GoogleFonts
                                                              .interTight(
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .displaySmall
                                                                    .fontStyle,
                                                          ),
                                                          fontSize: 25.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .displaySmall
                                                                  .fontStyle,
                                                        ),
                                                  ),
                                                ),
                                                Text(
                                                  valueOrDefault<String>(
                                                    widget!
                                                        .profileUser
                                                        ?.futureMods
                                                        ?.firstOrNull,
                                                    'Mod',
                                                  ),
                                                  textAlign: TextAlign.center,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .labelSmall
                                                      .override(
                                                        font: GoogleFonts.inter(
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontStyle,
                                                        ),
                                                        fontSize: 20.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontWeight,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontStyle,
                                                      ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
