import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/components/rided_added_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:async';
import 'dart:ui';
import '/index.dart';
import 'ride_widget.dart' show RideWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class RideModel extends FlutterFlowModel<RideWidget> {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  bool isDataUploading_uploadDataRideToFirebase = false;
  FFUploadedFile uploadedLocalFile_uploadDataRideToFirebase =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl_uploadDataRideToFirebase = '';

  // State field(s) for TextFieldRideName widget.
  FocusNode? textFieldRideNameFocusNode;
  TextEditingController? textFieldRideNameTextController;
  String? Function(BuildContext, String?)?
      textFieldRideNameTextControllerValidator;
  String? _textFieldRideNameTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Name is required';
    }

    return null;
  }

  // State field(s) for TextFieldRideMake widget.
  FocusNode? textFieldRideMakeFocusNode;
  TextEditingController? textFieldRideMakeTextController;
  String? Function(BuildContext, String?)?
      textFieldRideMakeTextControllerValidator;
  String? _textFieldRideMakeTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Year/Make/Model is required';
    }

    return null;
  }

  // Stores action output result for [Validate Form] action in Button widget.
  bool? updatedRide;
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  RidesRecord? newRide;

  @override
  void initState(BuildContext context) {
    textFieldRideNameTextControllerValidator =
        _textFieldRideNameTextControllerValidator;
    textFieldRideMakeTextControllerValidator =
        _textFieldRideMakeTextControllerValidator;
  }

  @override
  void dispose() {
    textFieldRideNameFocusNode?.dispose();
    textFieldRideNameTextController?.dispose();

    textFieldRideMakeFocusNode?.dispose();
    textFieldRideMakeTextController?.dispose();
  }
}
