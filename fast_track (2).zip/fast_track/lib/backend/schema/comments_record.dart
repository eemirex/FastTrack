import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CommentsRecord extends FirestoreRecord {
  CommentsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "victory_ref" field.
  DocumentReference? _victoryRef;
  DocumentReference? get victoryRef => _victoryRef;
  bool hasVictoryRef() => _victoryRef != null;

  // "user_ref" field.
  DocumentReference? _userRef;
  DocumentReference? get userRef => _userRef;
  bool hasUserRef() => _userRef != null;

  // "text" field.
  String? _text;
  String get text => _text ?? '';
  bool hasText() => _text != null;

  // "created_at" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  // "user_display_name" field.
  String? _userDisplayName;
  String get userDisplayName => _userDisplayName ?? '';
  bool hasUserDisplayName() => _userDisplayName != null;

  // "user_photo_url" field.
  String? _userPhotoUrl;
  String get userPhotoUrl => _userPhotoUrl ?? '';
  bool hasUserPhotoUrl() => _userPhotoUrl != null;

  // "victoryID" field.
  String? _victoryID;
  String get victoryID => _victoryID ?? '';
  bool hasVictoryID() => _victoryID != null;

  // "userID" field.
  String? _userID;
  String get userID => _userID ?? '';
  bool hasUserID() => _userID != null;

  void _initializeFields() {
    _victoryRef = snapshotData['victory_ref'] as DocumentReference?;
    _userRef = snapshotData['user_ref'] as DocumentReference?;
    _text = snapshotData['text'] as String?;
    _createdAt = snapshotData['created_at'] as DateTime?;
    _userDisplayName = snapshotData['user_display_name'] as String?;
    _userPhotoUrl = snapshotData['user_photo_url'] as String?;
    _victoryID = snapshotData['victoryID'] as String?;
    _userID = snapshotData['userID'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('comments');

  static Stream<CommentsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CommentsRecord.fromSnapshot(s));

  static Future<CommentsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CommentsRecord.fromSnapshot(s));

  static CommentsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CommentsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CommentsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CommentsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CommentsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CommentsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCommentsRecordData({
  DocumentReference? victoryRef,
  DocumentReference? userRef,
  String? text,
  DateTime? createdAt,
  String? userDisplayName,
  String? userPhotoUrl,
  String? victoryID,
  String? userID,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'victory_ref': victoryRef,
      'user_ref': userRef,
      'text': text,
      'created_at': createdAt,
      'user_display_name': userDisplayName,
      'user_photo_url': userPhotoUrl,
      'victoryID': victoryID,
      'userID': userID,
    }.withoutNulls,
  );

  return firestoreData;
}

class CommentsRecordDocumentEquality implements Equality<CommentsRecord> {
  const CommentsRecordDocumentEquality();

  @override
  bool equals(CommentsRecord? e1, CommentsRecord? e2) {
    return e1?.victoryRef == e2?.victoryRef &&
        e1?.userRef == e2?.userRef &&
        e1?.text == e2?.text &&
        e1?.createdAt == e2?.createdAt &&
        e1?.userDisplayName == e2?.userDisplayName &&
        e1?.userPhotoUrl == e2?.userPhotoUrl &&
        e1?.victoryID == e2?.victoryID &&
        e1?.userID == e2?.userID;
  }

  @override
  int hash(CommentsRecord? e) => const ListEquality().hash([
        e?.victoryRef,
        e?.userRef,
        e?.text,
        e?.createdAt,
        e?.userDisplayName,
        e?.userPhotoUrl,
        e?.victoryID,
        e?.userID
      ]);

  @override
  bool isValidKey(Object? o) => o is CommentsRecord;
}
