import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RaceRecord extends FirestoreRecord {
  RaceRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "date" field.
  DateTime? _date;
  DateTime? get date => _date;
  bool hasDate() => _date != null;

  // "location" field.
  String? _location;
  String get location => _location ?? '';
  bool hasLocation() => _location != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "maxParticipants" field.
  int? _maxParticipants;
  int get maxParticipants => _maxParticipants ?? 0;
  bool hasMaxParticipants() => _maxParticipants != null;

  // "participants" field.
  List<String>? _participants;
  List<String> get participants => _participants ?? const [];
  bool hasParticipants() => _participants != null;

  void _initializeFields() {
    _date = snapshotData['date'] as DateTime?;
    _location = snapshotData['location'] as String?;
    _description = snapshotData['description'] as String?;
    _maxParticipants = castToType<int>(snapshotData['maxParticipants']);
    _participants = getDataList(snapshotData['participants']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('race');

  static Stream<RaceRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RaceRecord.fromSnapshot(s));

  static Future<RaceRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => RaceRecord.fromSnapshot(s));

  static RaceRecord fromSnapshot(DocumentSnapshot snapshot) => RaceRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RaceRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RaceRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RaceRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RaceRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRaceRecordData({
  DateTime? date,
  String? location,
  String? description,
  int? maxParticipants,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'date': date,
      'location': location,
      'description': description,
      'maxParticipants': maxParticipants,
    }.withoutNulls,
  );

  return firestoreData;
}

class RaceRecordDocumentEquality implements Equality<RaceRecord> {
  const RaceRecordDocumentEquality();

  @override
  bool equals(RaceRecord? e1, RaceRecord? e2) {
    const listEquality = ListEquality();
    return e1?.date == e2?.date &&
        e1?.location == e2?.location &&
        e1?.description == e2?.description &&
        e1?.maxParticipants == e2?.maxParticipants &&
        listEquality.equals(e1?.participants, e2?.participants);
  }

  @override
  int hash(RaceRecord? e) => const ListEquality().hash([
        e?.date,
        e?.location,
        e?.description,
        e?.maxParticipants,
        e?.participants
      ]);

  @override
  bool isValidKey(Object? o) => o is RaceRecord;
}
