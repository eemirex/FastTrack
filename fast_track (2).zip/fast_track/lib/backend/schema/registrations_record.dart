import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RegistrationsRecord extends FirestoreRecord {
  RegistrationsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "registrationId" field.
  String? _registrationId;
  String get registrationId => _registrationId ?? '';
  bool hasRegistrationId() => _registrationId != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "raceId" field.
  DocumentReference? _raceId;
  DocumentReference? get raceId => _raceId;
  bool hasRaceId() => _raceId != null;

  // "userId" field.
  DocumentReference? _userId;
  DocumentReference? get userId => _userId;
  bool hasUserId() => _userId != null;

  void _initializeFields() {
    _registrationId = snapshotData['registrationId'] as String?;
    _status = snapshotData['status'] as String?;
    _raceId = snapshotData['raceId'] as DocumentReference?;
    _userId = snapshotData['userId'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('registrations');

  static Stream<RegistrationsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RegistrationsRecord.fromSnapshot(s));

  static Future<RegistrationsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => RegistrationsRecord.fromSnapshot(s));

  static RegistrationsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RegistrationsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RegistrationsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RegistrationsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RegistrationsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RegistrationsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRegistrationsRecordData({
  String? registrationId,
  String? status,
  DocumentReference? raceId,
  DocumentReference? userId,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'registrationId': registrationId,
      'status': status,
      'raceId': raceId,
      'userId': userId,
    }.withoutNulls,
  );

  return firestoreData;
}

class RegistrationsRecordDocumentEquality
    implements Equality<RegistrationsRecord> {
  const RegistrationsRecordDocumentEquality();

  @override
  bool equals(RegistrationsRecord? e1, RegistrationsRecord? e2) {
    return e1?.registrationId == e2?.registrationId &&
        e1?.status == e2?.status &&
        e1?.raceId == e2?.raceId &&
        e1?.userId == e2?.userId;
  }

  @override
  int hash(RegistrationsRecord? e) => const ListEquality()
      .hash([e?.registrationId, e?.status, e?.raceId, e?.userId]);

  @override
  bool isValidKey(Object? o) => o is RegistrationsRecord;
}
