// Export pages
export '/other/pages/home_page/home_page_widget.dart' show HomePageWidget;
export '/other/pages/ride/ride_widget.dart' show RideWidget;
export '/other/pages/create_race/create_race_widget.dart' show CreateRaceWidget;
export '/other/pages/privacy_policy/privacy_policy_widget.dart'
    show PrivacyPolicyWidget;
export '/other/pages/term_of_service/term_of_service_widget.dart'
    show TermOfServiceWidget;
export '/other/pages/my_rides/my_rides_widget.dart' show MyRidesWidget;
export '/other/pages/my_victories/my_victories_widget.dart'
    show MyVictoriesWidget;
export '/other/pages/settings/settings_widget.dart' show SettingsWidget;
export '/other/pages/specification/specification_widget.dart'
    show SpecificationWidget;
export '/victory_info/victory_info_widget.dart' show VictoryInfoWidget;
export '/edit_profile/edit_profile_widget.dart' show EditProfileWidget;
export '/races/races_widget.dart' show RacesWidget;
export '/other/pages/edit_specification/edit_specification_widget.dart'
    show EditSpecificationWidget;
export '/other/pages/profile/profile_widget.dart' show ProfileWidget;
export '/find_track/find_track_widget.dart' show FindTrackWidget;
export '/other/pages/social_feed/social_feed_widget.dart' show SocialFeedWidget;
export '/new_post/new_post_widget.dart' show NewPostWidget;
export '/other/pages/my_profile/my_profile_widget.dart' show MyProfileWidget;
export '/create_profile/create_profile_widget.dart' show CreateProfileWidget;
export '/account_profile_creation/auth_2_create/auth2_create_widget.dart'
    show Auth2CreateWidget;
export '/account_profile_creation/auth_2_login/auth2_login_widget.dart'
    show Auth2LoginWidget;
export '/account_profile_creation/auth_2_forgot_password/auth2_forgot_password_widget.dart'
    show Auth2ForgotPasswordWidget;
export '/account_profile_creation/auth_2_create_profile/auth2_create_profile_widget.dart'
    show Auth2CreateProfileWidget;
export '/account_profile_creation/auth_2_profile/auth2_profile_widget.dart'
    show Auth2ProfileWidget;
export '/account_profile_creation/auth_2_edit_profile/auth2_edit_profile_widget.dart'
    show Auth2EditProfileWidget;
