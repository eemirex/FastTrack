import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/comments1_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'my_victories_model.dart';
export 'my_victories_model.dart';

class MyVictoriesWidget extends StatefulWidget {
  const MyVictoriesWidget({
    super.key,
    this.user,
  });

  final UserRecord? user;

  static String routeName = 'myVictories';
  static String routePath = '/myVictories';

  @override
  State<MyVictoriesWidget> createState() => _MyVictoriesWidgetState();
}

class _MyVictoriesWidgetState extends State<MyVictoriesWidget> {
  late MyVictoriesModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MyVictoriesModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<VictoriesRecord>>(
      stream: queryVictoriesRecord(
        queryBuilder: (victoriesRecord) => victoriesRecord.orderBy('raceName'),
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
            body: Center(
              child: SizedBox(
                width: 50.0,
                height: 50.0,
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    FlutterFlowTheme.of(context).primary,
                  ),
                ),
              ),
            ),
          );
        }
        List<VictoriesRecord> myVictoriesVictoriesRecordList = snapshot.data!;

        return GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
            FocusManager.instance.primaryFocus?.unfocus();
          },
          child: Scaffold(
            key: scaffoldKey,
            backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
            appBar: AppBar(
              backgroundColor: Color(0xFFFF1200),
              automaticallyImplyLeading: false,
              leading: FlutterFlowIconButton(
                buttonSize: 40.0,
                icon: Icon(
                  Icons.arrow_back,
                  color: Colors.white,
                  size: 24.0,
                ),
                onPressed: () async {
                  context.safePop();
                },
              ),
              title: Text(
                'My Victories',
                style: FlutterFlowTheme.of(context).headlineMedium.override(
                      font: GoogleFonts.interTight(
                        fontWeight: FlutterFlowTheme.of(context)
                            .headlineMedium
                            .fontWeight,
                        fontStyle: FlutterFlowTheme.of(context)
                            .headlineMedium
                            .fontStyle,
                      ),
                      color: Colors.white,
                      fontSize: 28.0,
                      letterSpacing: 0.0,
                      fontWeight: FlutterFlowTheme.of(context)
                          .headlineMedium
                          .fontWeight,
                      fontStyle:
                          FlutterFlowTheme.of(context).headlineMedium.fontStyle,
                    ),
              ),
              actions: [],
              centerTitle: true,
              elevation: 2.0,
            ),
            body: SafeArea(
              top: true,
              child: Align(
                alignment: AlignmentDirectional(0.0, 0.0),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Align(
                        alignment: AlignmentDirectional(0.0, 0.0),
                        child: Container(
                          decoration: BoxDecoration(),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 15.0, 0.0, 0.0),
                                child: Container(
                                  width:
                                      MediaQuery.sizeOf(context).width * 0.95,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                    borderRadius: BorderRadius.circular(12.0),
                                  ),
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        24.0, 24.0, 24.0, 24.0),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Row(
                                          mainAxisSize: MainAxisSize.max,
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Column(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                Text(
                                                  'Total Wins',
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .headlineSmall
                                                      .override(
                                                        font: GoogleFonts
                                                            .interTight(
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .headlineSmall
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .headlineSmall
                                                                  .fontStyle,
                                                        ),
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .primaryText,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .headlineSmall
                                                                .fontWeight,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .headlineSmall
                                                                .fontStyle,
                                                      ),
                                                ),
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 0.0, 0.0, 10.0),
                                                  child: Text(
                                                    valueOrDefault<String>(
                                                      myVictoriesVictoriesRecordList
                                                          .length
                                                          .toString(),
                                                      '0',
                                                    ),
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .displayLarge
                                                        .override(
                                                          font: GoogleFonts
                                                              .interTight(
                                                            fontWeight:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .displayLarge
                                                                    .fontWeight,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .displayLarge
                                                                    .fontStyle,
                                                          ),
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .primary,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .displayLarge
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .displayLarge
                                                                  .fontStyle,
                                                        ),
                                                  ),
                                                ),
                                                Row(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  children: [
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  0.0,
                                                                  10.0,
                                                                  0.0),
                                                      child: FFButtonWidget(
                                                        onPressed: () async {
                                                          context.pushNamed(
                                                              VictoryInfoWidget
                                                                  .routeName);
                                                        },
                                                        text: 'Add Victory',
                                                        options:
                                                            FFButtonOptions(
                                                          height: 40.0,
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      16.0,
                                                                      0.0,
                                                                      16.0,
                                                                      0.0),
                                                          iconPadding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      0.0,
                                                                      0.0,
                                                                      0.0),
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .primary,
                                                          textStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .titleSmall
                                                                  .override(
                                                                    font: GoogleFonts
                                                                        .interTight(
                                                                      fontWeight: FlutterFlowTheme.of(
                                                                              context)
                                                                          .titleSmall
                                                                          .fontWeight,
                                                                      fontStyle: FlutterFlowTheme.of(
                                                                              context)
                                                                          .titleSmall
                                                                          .fontStyle,
                                                                    ),
                                                                    color: Colors
                                                                        .white,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight: FlutterFlowTheme.of(
                                                                            context)
                                                                        .titleSmall
                                                                        .fontWeight,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .titleSmall
                                                                        .fontStyle,
                                                                  ),
                                                          elevation: 0.0,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      8.0),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ].divide(SizedBox(height: 16.0)),
                                    ),
                                  ),
                                ),
                              ),
                              Align(
                                alignment: AlignmentDirectional(0.0, 0.0),
                                child: Container(
                                  width:
                                      MediaQuery.sizeOf(context).width * 0.95,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .primaryBackground,
                                    borderRadius: BorderRadius.circular(12.0),
                                  ),
                                  child: Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        24.0, 24.0, 24.0, 24.0),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Text(
                                          'Recent Victories',
                                          style: FlutterFlowTheme.of(context)
                                              .headlineSmall
                                              .override(
                                                font: GoogleFonts.interTight(
                                                  fontWeight:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .headlineSmall
                                                          .fontWeight,
                                                  fontStyle:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .headlineSmall
                                                          .fontStyle,
                                                ),
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryText,
                                                letterSpacing: 0.0,
                                                fontWeight:
                                                    FlutterFlowTheme.of(context)
                                                        .headlineSmall
                                                        .fontWeight,
                                                fontStyle:
                                                    FlutterFlowTheme.of(context)
                                                        .headlineSmall
                                                        .fontStyle,
                                              ),
                                        ),
                                        Builder(
                                          builder: (context) {
                                            final victories =
                                                myVictoriesVictoriesRecordList
                                                    .toList();
                                            if (victories.isEmpty) {
                                              return Center(
                                                child: CachedNetworkImage(
                                                  fadeInDuration:
                                                      Duration(milliseconds: 0),
                                                  fadeOutDuration:
                                                      Duration(milliseconds: 0),
                                                  imageUrl:
                                                      'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMIAAAEDCAMAAABQ/CumAAAAgVBMVEUAAAD////d3d3Dw8Onp6cODg5cXFxpaWlRUVHOzs6jo6PIyMi9vb36+vooKChXV1fy8vI7Ozt4eHi4uLhwcHCEhISenp5HR0e0tLSSkpJBQUFkZGStrq3k5ORMTEyRkZEyMjIbGxsiIiLr6+vX19eIiIgkJCR9fX0TExMuLi4bHBtvMEk+AAAJeElEQVR4nO2c62KiOBSAE0ARBQVBlJtixarz/g+4uZIEtWVLsZ3d8/3oUAqYjySQcxIHIQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOC/SLROimIlflmt3SS5il+Wh/l8nu7bA4uiSNYJOZock7hFMaV7Z2uX7p7Q7S3fXiI0oRctEnrZKT00Etdw1+66kBecbMj1s+l02n7EF6ndFGMsPmNf2Ik74ds+vhyJVGWJTyjJYRu3yDC2pq7bkN/YGdMK44yfExUexk7xRkrnHjA+FfTMWbHAuBIfNi0abk7IgsORuAbkegMVECpIaWz5iyP+vZ7wlm+dsCuUTkd+tMeNgiPbT4otS0WOwRe+tVIlo+5Je4TcsMVZf0J8Gqywtsln1FJB1EHTWiUYL/ke5uQKBWQJx+YzhbRR1YDkVVNciq0Ch4MVLkmoqkEouNqNC3BM/znZ8i9cYYp5qya10DZvorC5U5hPyS1yTYUc4zd5UhO8D1YoaG/IDQVSrraThbzVi4K2Cihcy0P1WrhXcFClqkEo2LhpP38tm+wAhYTcaFkNQiFsezhtMfQevonqVgp+1lchUb2Bf8wfUbMcdf4ABaetBq5QY1OBFDavugqHuK8CrQZLVyDPBNkV6Aesv0HhSorsawrbjkJKiu51FcSePgqXthq4wsFQiNNvUGDVUD9XmCN023YV3ma9FVRv4ApzQyH6jr6AjvLd8FRBohQEvRQ25ILrZwrDoQooFoUeSYE+H6qRFW44YNXwJQU5xKI34onCWfQGruCMocCqYfsVBfLuXcR+TPDj6qmCrIYxFSL+UPqSQo9aQBmvhjEVaDvG9Wh9QVbDXV9Y76ymKeUAf5hCxB5KX1L4eIwkFFL2ULrvzlttEDhQAZFxPb6NVwuTgJZ1XIU97Q3paAq03LjgY4B0JAVamIDfpfx+gDFcAZGLVlzhMpbCDItoEi07CuePFXr1BR6+tbdoN4oCkgExjTZlAMHGN1qAPqAW3lWEW6mLfK/CqlXYaQ/7wIgMByjQqy74VoIDufN7FWib4RtL1Xhqox0NUri1CiRsk/3rmxUKqUBG9DKv4JhFfvR2/jj8Vwrk7d2mSjwZThOFwSkMTYG0Ubm1ETfsooeISCVhWj5NwmgKy7YW6IijZA9wBwcDo7ap7fv2rC1ge5fQNfXSLLNjI9d29GOfoKQ3ZIBHLsAGCAkb7NnkOXC16cDPpw0wI4fHE3l4mmkXOy/KNCstfdf3cxz16oTr2+fHAAAAAAAAAP9TlnmU72ezfZ5v6c8ob+N+VKSOc36UaFtl83lS1zX922TFT6WQrZxOj77PtpHaF+UDk3WfQfPB8+xAopXqnGWnNnxGKXbeSRAQenXnjHmT7Y8FTWDS4PGaxfxUAk0V0QgpP5BAyDvQXQcSMBuR6wgscEjLmIjsgicDc0/O8IV4ph9/PYnJygvGPCArVEhch2Iqc66ST1N53GhUPMWylgmSkM+U+218ucbBxDh+KbZKkQxylQKJhHksrymgs0oajUNoi4JiuUHTLzNV+0djhjXTlkyIO64rIJtnbBw9BXhSfx6FgOfiWgUU0NRCrCWSKrncgv+iyhPz1IOhUPB2qNcCOgxfovARkbi8UvBoEiLEak7e0lKOk1CrBZcX11BAAXuiGQr5uAp7USKlMKcpBWwqtMVZBrjtC+gtZLVjKjSs8xsK6DTqUzURBVcKa5vPl+gKqj+GcpKd/cISr6aCx1JcpkI1eGb5I3LRRpRC5PLsvK6g+jN54Mt0F3mu3uhPqTBlua2CaUmFC/uZ3MZUkKy1dVUdhUZXoEtCcGKcKhUyrB6+UsEO0Mvoq0BehUGAF0vtVKlweKDgj9uTDXor0PkGjAMtjSgVzg8U4l+pwOYVMbbaZCtRqOaOM/c0BfJqa8i+tPqdCsgNmYQc+TxqSM6vbkiUkjmIKb+/UwHtWY/gEwsfdedf2hc49AVhDvMOWL2E24fq71O4qikeEh0FDwYY5YO38yJHL8BUiDoK2gCjndRYyWM6AwzWujoDjPr7C3yPqYA6CuotELaDVjrwYA9WU+HE9pkKr2lNHYWTqaBWklpqIdFOLEk0FG587a+hUPyIwk4rdoVD9ajx1aCnFEGmoXB4EPL4w9fG96GjQDrDQWy+B3r4XqoxnieGrIZCeB94Ho0rj0dHQYuRz8bsfNouZ8jlc0pXKMVpei0037uK7SldBVJW/hia4uaPtntDBkQstFyF3QEG0lZZKIU3z1jPNBq32Pe8RVzo+/J4MT9nvmfOzc+spjnZc8ffie5+9empO4bfeB5tf/vY9jyb7yNbjYt+jMnt8dT2EWa8AQAAAAAAgLF5y+vlss5ZSHDNI7pNg98oui1vESUnW0uWyN7mdR1tCZG2+PNG/8yOy6NaHPhi9imd5ebfj69TG2Mro/OEhzTAYUrJUvmdtLTE+JSRHbswsGVkndDZ9jJjR1o4wM8+Z1T0GPHSTkMd1YL5ayWm09UqZj0Ss9SXA2w8/Iu/X8HRirNpFZaByltMAsyazlQtxD6pWVCi0C4PsPCPBGifK6AD/06JppCqeFlX2Kt5uFfSQ+HIb7mmsFJL9nUFVI27iPwJPRRQw3IAmsIVt13FUHAe5MDHp4+Cw26upjB5ouCaX254EX0ULuzm9lCoB3+p5St8rHDM6NzAlvVSTeF23xcOtL9cf2FfiLBKhWkKidqUCo+mgl7EZwpqql9T2KmTWoWRF059gPPw7bwUb+f6ocKW/FUOlOTb+QcV5nyWmzJf6ArBgZCaDanaT1ezpMSB3eYkiYJDDhx9+doHEAXneGO8nY1aoCs+p6bC6bJJ4wBbWgKZ/m8lZJx6+9mG9KQv0H8fNiRHz+T/jr7wr59IpTaP+5cq6P/vza9/qE72tN8W7AhNoVRzcVJhWyP6vcLXFNqkzwBjwxqJprBWC2GMAUb+msnNDn0UdmzdrTnYlnOAhsJ65FW1j+mjUHUH29snCvFrJjc79FCo70KeZwrhAf0APRR2d4HnE4XktwaeK7F2XlN4p915y8Q0hWOIjXnfVzE3FcRTUUvCTIO7JAx9MfjozIZ3Kglzq34kCTNzbMuyHXYfozK2rIVDs1yZY1kNH/uVlmWxcNLZWY3niCwLkS2p7drxLKvkR5IDf+SZ+lWu7uD/Kw4AAAAAAAAAAAAAAAAAgC7/ADSUlF7QO2uKAAAAAElFTkSuQmCC',
                                                ),
                                              );
                                            }

                                            return ListView.builder(
                                              padding: EdgeInsets.zero,
                                              primary: false,
                                              shrinkWrap: true,
                                              scrollDirection: Axis.vertical,
                                              itemCount: victories.length,
                                              itemBuilder:
                                                  (context, victoriesIndex) {
                                                final victoriesItem =
                                                    victories[victoriesIndex];
                                                return Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 0.0, 0.0, 20.0),
                                                  child: Container(
                                                    width: MediaQuery.sizeOf(
                                                                context)
                                                            .width *
                                                        1.0,
                                                    decoration: BoxDecoration(
                                                      color: Color(0xFF1A1A1A),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              16.0),
                                                    ),
                                                    child: Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  20.0),
                                                      child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        children: [
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        16.0,
                                                                        16.0,
                                                                        16.0,
                                                                        16.0),
                                                            child: Column(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              children: [
                                                                ClipRRect(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              12.0),
                                                                  child:
                                                                      CachedNetworkImage(
                                                                    fadeInDuration:
                                                                        Duration(
                                                                            milliseconds:
                                                                                0),
                                                                    fadeOutDuration:
                                                                        Duration(
                                                                            milliseconds:
                                                                                0),
                                                                    imageUrl:
                                                                        '',
                                                                    width: double
                                                                        .infinity,
                                                                    height:
                                                                        200.0,
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                                Row(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .spaceBetween,
                                                                  children: [
                                                                    Column(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .max,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Text(
                                                                          valueOrDefault<
                                                                              String>(
                                                                            victoriesItem.raceName,
                                                                            'Race',
                                                                          ),
                                                                          style: FlutterFlowTheme.of(context)
                                                                              .titleMedium
                                                                              .override(
                                                                                font: GoogleFonts.interTight(
                                                                                  fontWeight: FlutterFlowTheme.of(context).titleMedium.fontWeight,
                                                                                  fontStyle: FlutterFlowTheme.of(context).titleMedium.fontStyle,
                                                                                ),
                                                                                color: Colors.white,
                                                                                letterSpacing: 0.0,
                                                                                fontWeight: FlutterFlowTheme.of(context).titleMedium.fontWeight,
                                                                                fontStyle: FlutterFlowTheme.of(context).titleMedium.fontStyle,
                                                                              ),
                                                                        ),
                                                                        Text(
                                                                          valueOrDefault<
                                                                              String>(
                                                                            dateTimeFormat("MMMEd",
                                                                                victoriesItem.timeStamp),
                                                                            'Mon, Aug 18',
                                                                          ),
                                                                          style: FlutterFlowTheme.of(context)
                                                                              .bodySmall
                                                                              .override(
                                                                                font: GoogleFonts.inter(
                                                                                  fontWeight: FlutterFlowTheme.of(context).bodySmall.fontWeight,
                                                                                  fontStyle: FlutterFlowTheme.of(context).bodySmall.fontStyle,
                                                                                ),
                                                                                color: Color(0xFF9E9E9E),
                                                                                letterSpacing: 0.0,
                                                                                fontWeight: FlutterFlowTheme.of(context).bodySmall.fontWeight,
                                                                                fontStyle: FlutterFlowTheme.of(context).bodySmall.fontStyle,
                                                                              ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                    Expanded(
                                                                      child:
                                                                          Align(
                                                                        alignment: AlignmentDirectional(
                                                                            1.0,
                                                                            0.0),
                                                                        child:
                                                                            FaIcon(
                                                                          FontAwesomeIcons
                                                                              .trophy,
                                                                          color:
                                                                              FlutterFlowTheme.of(context).primaryText,
                                                                          size:
                                                                              24.0,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Padding(
                                                                      padding: EdgeInsetsDirectional.fromSTEB(
                                                                          8.0,
                                                                          16.0,
                                                                          8.0,
                                                                          16.0),
                                                                      child:
                                                                          Container(
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          color:
                                                                              FlutterFlowTheme.of(context).primary,
                                                                          borderRadius:
                                                                              BorderRadius.circular(20.0),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                                Row(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  children: [
                                                                    Icon(
                                                                      Icons
                                                                          .place,
                                                                      color: Color(
                                                                          0xFF9E9E9E),
                                                                      size:
                                                                          20.0,
                                                                    ),
                                                                    Text(
                                                                      victoriesItem
                                                                          .location,
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyMedium
                                                                          .override(
                                                                            font:
                                                                                GoogleFonts.inter(
                                                                              fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                              fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                            ),
                                                                            color:
                                                                                Color(0xFF9E9E9E),
                                                                            letterSpacing:
                                                                                0.0,
                                                                            fontWeight:
                                                                                FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                            fontStyle:
                                                                                FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                          ),
                                                                    ),
                                                                  ].divide(SizedBox(
                                                                      width:
                                                                          8.0)),
                                                                ),
                                                                Row(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  children: [
                                                                    Column(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .max,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Text(
                                                                          'Time',
                                                                          style: FlutterFlowTheme.of(context)
                                                                              .bodySmall
                                                                              .override(
                                                                                font: GoogleFonts.inter(
                                                                                  fontWeight: FlutterFlowTheme.of(context).bodySmall.fontWeight,
                                                                                  fontStyle: FlutterFlowTheme.of(context).bodySmall.fontStyle,
                                                                                ),
                                                                                color: Color(0xFF9E9E9E),
                                                                                letterSpacing: 0.0,
                                                                                fontWeight: FlutterFlowTheme.of(context).bodySmall.fontWeight,
                                                                                fontStyle: FlutterFlowTheme.of(context).bodySmall.fontStyle,
                                                                              ),
                                                                        ),
                                                                        Text(
                                                                          valueOrDefault<
                                                                              String>(
                                                                            dateTimeFormat("Hm",
                                                                                victoriesItem.timeStamp),
                                                                            '02:45',
                                                                          ),
                                                                          style: FlutterFlowTheme.of(context)
                                                                              .bodyLarge
                                                                              .override(
                                                                                font: GoogleFonts.inter(
                                                                                  fontWeight: FlutterFlowTheme.of(context).bodyLarge.fontWeight,
                                                                                  fontStyle: FlutterFlowTheme.of(context).bodyLarge.fontStyle,
                                                                                ),
                                                                                color: Colors.white,
                                                                                letterSpacing: 0.0,
                                                                                fontWeight: FlutterFlowTheme.of(context).bodyLarge.fontWeight,
                                                                                fontStyle: FlutterFlowTheme.of(context).bodyLarge.fontStyle,
                                                                              ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                    Column(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .max,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Text(
                                                                          'Distance',
                                                                          style: FlutterFlowTheme.of(context)
                                                                              .bodySmall
                                                                              .override(
                                                                                font: GoogleFonts.inter(
                                                                                  fontWeight: FlutterFlowTheme.of(context).bodySmall.fontWeight,
                                                                                  fontStyle: FlutterFlowTheme.of(context).bodySmall.fontStyle,
                                                                                ),
                                                                                color: Color(0xFF9E9E9E),
                                                                                letterSpacing: 0.0,
                                                                                fontWeight: FlutterFlowTheme.of(context).bodySmall.fontWeight,
                                                                                fontStyle: FlutterFlowTheme.of(context).bodySmall.fontStyle,
                                                                              ),
                                                                        ),
                                                                        Text(
                                                                          victoriesItem
                                                                              .distance,
                                                                          style: FlutterFlowTheme.of(context)
                                                                              .bodyLarge
                                                                              .override(
                                                                                font: GoogleFonts.inter(
                                                                                  fontWeight: FlutterFlowTheme.of(context).bodyLarge.fontWeight,
                                                                                  fontStyle: FlutterFlowTheme.of(context).bodyLarge.fontStyle,
                                                                                ),
                                                                                color: Colors.white,
                                                                                letterSpacing: 0.0,
                                                                                fontWeight: FlutterFlowTheme.of(context).bodyLarge.fontWeight,
                                                                                fontStyle: FlutterFlowTheme.of(context).bodyLarge.fontStyle,
                                                                              ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ].divide(SizedBox(
                                                                      width:
                                                                          16.0)),
                                                                ),
                                                                Row(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  children: [
                                                                    Row(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .max,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceBetween,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .center,
                                                                      children: [
                                                                        Row(
                                                                          mainAxisSize:
                                                                              MainAxisSize.max,
                                                                          children:
                                                                              [
                                                                            Row(
                                                                              mainAxisSize: MainAxisSize.max,
                                                                              children: [
                                                                                FlutterFlowIconButton(
                                                                                  borderRadius: 18.0,
                                                                                  buttonSize: 36.0,
                                                                                  fillColor: victoriesItem.likes.contains(victoriesItem.reference) ? Color(0x00000000) : FlutterFlowTheme.of(context).primary,
                                                                                  icon: Icon(
                                                                                    Icons.favorite_border,
                                                                                    color: FlutterFlowTheme.of(context).secondaryText,
                                                                                    size: 20.0,
                                                                                  ),
                                                                                  onPressed: () async {
                                                                                    if (victoriesItem.likes.contains(currentUserReference)) {
                                                                                      await victoriesItem.reference.update({
                                                                                        ...mapToFirestore(
                                                                                          {
                                                                                            'likes': FieldValue.arrayRemove([
                                                                                              widget!.user?.reference
                                                                                            ]),
                                                                                          },
                                                                                        ),
                                                                                      });
                                                                                    } else {
                                                                                      await victoriesItem.reference.update({
                                                                                        ...mapToFirestore(
                                                                                          {
                                                                                            'likes': FieldValue.arrayUnion([
                                                                                              widget!.user?.reference
                                                                                            ]),
                                                                                          },
                                                                                        ),
                                                                                      });
                                                                                    }
                                                                                  },
                                                                                ),
                                                                                Text(
                                                                                  valueOrDefault<String>(
                                                                                    victoriesItem.likes.length.toString(),
                                                                                    '0',
                                                                                  ),
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        font: GoogleFonts.inter(
                                                                                          fontWeight: FontWeight.w500,
                                                                                          fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                        ),
                                                                                        color: Colors.white,
                                                                                        letterSpacing: 0.0,
                                                                                        fontWeight: FontWeight.w500,
                                                                                        fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                      ),
                                                                                ),
                                                                              ].divide(SizedBox(width: 8.0)),
                                                                            ),
                                                                            Row(
                                                                              mainAxisSize: MainAxisSize.max,
                                                                              children: [
                                                                                StreamBuilder<List<CommentsRecord>>(
                                                                                  stream: queryCommentsRecord(
                                                                                    queryBuilder: (commentsRecord) => commentsRecord
                                                                                        .where(
                                                                                          'victory_ref',
                                                                                          isEqualTo: victoriesItem.reference,
                                                                                        )
                                                                                        .orderBy('created_at'),
                                                                                  ),
                                                                                  builder: (context, snapshot) {
                                                                                    // Customize what your widget looks like when it's loading.
                                                                                    if (!snapshot.hasData) {
                                                                                      return Center(
                                                                                        child: SizedBox(
                                                                                          width: 50.0,
                                                                                          height: 50.0,
                                                                                          child: CircularProgressIndicator(
                                                                                            valueColor: AlwaysStoppedAnimation<Color>(
                                                                                              FlutterFlowTheme.of(context).primary,
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      );
                                                                                    }
                                                                                    List<CommentsRecord> iconButtonCommentsRecordList = snapshot.data!;

                                                                                    return FlutterFlowIconButton(
                                                                                      borderRadius: 18.0,
                                                                                      buttonSize: 36.0,
                                                                                      icon: Icon(
                                                                                        Icons.chat_bubble_outline,
                                                                                        color: Color(0xFF00D4FF),
                                                                                        size: 20.0,
                                                                                      ),
                                                                                      onPressed: () async {
                                                                                        await showModalBottomSheet(
                                                                                          isScrollControlled: true,
                                                                                          backgroundColor: Colors.transparent,
                                                                                          enableDrag: false,
                                                                                          context: context,
                                                                                          builder: (context) {
                                                                                            return GestureDetector(
                                                                                              onTap: () {
                                                                                                FocusScope.of(context).unfocus();
                                                                                                FocusManager.instance.primaryFocus?.unfocus();
                                                                                              },
                                                                                              child: Padding(
                                                                                                padding: MediaQuery.viewInsetsOf(context),
                                                                                                child: Comments1Widget(
                                                                                                  victoryRef: victoriesItem.reference,
                                                                                                ),
                                                                                              ),
                                                                                            );
                                                                                          },
                                                                                        ).then((value) => safeSetState(() {}));
                                                                                      },
                                                                                    );
                                                                                  },
                                                                                ),
                                                                                Text(
                                                                                  valueOrDefault<String>(
                                                                                    victoriesItem.numVictoryComments.toString(),
                                                                                    '0',
                                                                                  ),
                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                        font: GoogleFonts.inter(
                                                                                          fontWeight: FontWeight.w500,
                                                                                          fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                        ),
                                                                                        color: Colors.white,
                                                                                        letterSpacing: 0.0,
                                                                                        fontWeight: FontWeight.w500,
                                                                                        fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                      ),
                                                                                ),
                                                                              ].divide(SizedBox(width: 8.0)),
                                                                            ),
                                                                            Builder(
                                                                              builder: (context) => FlutterFlowIconButton(
                                                                                borderRadius: 18.0,
                                                                                buttonSize: 36.0,
                                                                                icon: Icon(
                                                                                  Icons.share,
                                                                                  color: Color(0xFF888888),
                                                                                  size: 20.0,
                                                                                ),
                                                                                onPressed: () async {
                                                                                  await Share.share(
                                                                                    '\'Check out this post on FastTrack! 🚀\'',
                                                                                    sharePositionOrigin: getWidgetBoundingBox(context),
                                                                                  );
                                                                                },
                                                                              ),
                                                                            ),
                                                                          ].divide(SizedBox(width: 24.0)),
                                                                        ),
                                                                        Text(
                                                                          valueOrDefault<
                                                                              String>(
                                                                            dateTimeFormat("relative",
                                                                                victoriesItem.timeStamp),
                                                                            '3 seconds ago',
                                                                          ),
                                                                          style: FlutterFlowTheme.of(context)
                                                                              .bodySmall
                                                                              .override(
                                                                                font: GoogleFonts.inter(
                                                                                  fontWeight: FlutterFlowTheme.of(context).bodySmall.fontWeight,
                                                                                  fontStyle: FlutterFlowTheme.of(context).bodySmall.fontStyle,
                                                                                ),
                                                                                color: Color(0xFF888888),
                                                                                letterSpacing: 0.0,
                                                                                fontWeight: FlutterFlowTheme.of(context).bodySmall.fontWeight,
                                                                                fontStyle: FlutterFlowTheme.of(context).bodySmall.fontStyle,
                                                                              ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ],
                                                                ),
                                                              ].divide(SizedBox(
                                                                  height:
                                                                      16.0)),
                                                            ),
                                                          ),
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        16.0,
                                                                        0.0,
                                                                        16.0,
                                                                        24.0),
                                                            child: Container(
                                                              width: double
                                                                  .infinity,
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .secondaryBackground,
                                                                boxShadow: [
                                                                  BoxShadow(
                                                                    blurRadius:
                                                                        5.0,
                                                                    color: Color(
                                                                        0x162D3A21),
                                                                    offset:
                                                                        Offset(
                                                                      0.0,
                                                                      3.0,
                                                                    ),
                                                                  )
                                                                ],
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            8.0),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                );
                                              },
                                            );
                                          },
                                        ),
                                      ].divide(SizedBox(height: 16.0)),
                                    ),
                                  ),
                                ),
                              ),
                            ].divide(SizedBox(height: 24.0)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
