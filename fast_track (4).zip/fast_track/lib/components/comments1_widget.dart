import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'comments1_model.dart';
export 'comments1_model.dart';

class Comments1Widget extends StatefulWidget {
  const Comments1Widget({
    super.key,
    required this.victoryRef,
  });

  final DocumentReference? victoryRef;

  @override
  State<Comments1Widget> createState() => _Comments1WidgetState();
}

class _Comments1WidgetState extends State<Comments1Widget> {
  late Comments1Model _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Comments1Model());

    _model.textController ??= TextEditingController();
    _model.textFieldFocusNode ??= FocusNode();
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          Container(
            decoration: BoxDecoration(
              color: Colors.transparent,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Padding(
                  padding:
                      EdgeInsetsDirectional.fromSTEB(16.0, 16.0, 16.0, 16.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Comments',
                        style:
                            FlutterFlowTheme.of(context).headlineSmall.override(
                                  font: GoogleFonts.interTight(
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .headlineSmall
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .headlineSmall
                                        .fontStyle,
                                  ),
                                  letterSpacing: 0.0,
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .headlineSmall
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .headlineSmall
                                      .fontStyle,
                                ),
                      ),
                      StreamBuilder<List<CommentsRecord>>(
                        stream: queryCommentsRecord(
                          queryBuilder: (commentsRecord) => commentsRecord
                              .where(
                                'victory_ref',
                                isEqualTo: widget!.victoryRef,
                              )
                              .orderBy('created_at'),
                        ),
                        builder: (context, snapshot) {
                          // Customize what your widget looks like when it's loading.
                          if (!snapshot.hasData) {
                            return Center(
                              child: SizedBox(
                                width: 50.0,
                                height: 50.0,
                                child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    FlutterFlowTheme.of(context).primary,
                                  ),
                                ),
                              ),
                            );
                          }
                          List<CommentsRecord> columnCommentsRecordList =
                              snapshot.data!;

                          return Column(
                            mainAxisSize: MainAxisSize.min,
                            children: List.generate(
                                columnCommentsRecordList.length, (columnIndex) {
                              final columnCommentsRecord =
                                  columnCommentsRecordList[columnIndex];
                              return Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Container(
                                    width: 40.0,
                                    height: 40.0,
                                    decoration: BoxDecoration(
                                      color:
                                          FlutterFlowTheme.of(context).accent2,
                                      borderRadius: BorderRadius.circular(20.0),
                                    ),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20.0),
                                      child: Image.network(
                                        'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJQAAACUCAMAAABC4vDmAAAAY1BMVEX///8AAADR0dHl5eX29vbi4uLw8PCqqqp0dHTt7e3a2tr8/Pw/Pz+UlJTz8/NlZWWEhIQxMTE6OjpcXFyOjo4ODg5GRkbFxcVUVFSwsLAcHBwhISFLS0u8vLyioqIXFxcpKSkQ0Ih2AAAHbElEQVR4nO1c2baiOhRUBhkUAVFx1v//ytuezk4CZKhA8LjW7XrrPhKKZGfPyWLxD/9nrFdhnOcBQ57H4Wr9q4TiNimq8lg/lxzP+lhWRdLGv0Joe05v9WWpwaW+peftRwnFQVXr6Mio98GHZiy6V0eE0V8cq3s0N6N1VtUHnNIbh7rK5hT9bVu6ESKU7WzylTTjKP3QSuZgFN13inc9680pLc5tHmZRlIV5ey7S00bWERw778K1bm+Dt7yafdJmql9nbbJvroMHbq1X2YrTvnQf0jZXEuLE8lbxkD8NET16Y2/SHHsyTzc9Yg9Pa9h25fuQ3h220vaedgWsaX1wenQHrXLHb43yqjPAdfo+jE/ygLti1OxHRWfnNhMlK5Bt3KsYPVpcyJuxDqZwSuSlK8MpQ4WyMbicR48TycLQTPq6NwJ5w1Qjd+EqlbZc4cF4bQuJVboaM0Qk6fDN5Gn6i2AjxjyNmKtMPH9I/VB6Q9LyG6NFUHISquDg08CvE8Hq5MgqEvP0BE0KilyaK6cVXIl5aiYpAhVCMfjJQdojse9K54W3IxMqK8WdmWrMQw5YC1YV+kwyWcXZIKllcBcF3Laks0VHEZ+rC6QCY26DyxkjI7GCNWLl+d5onGR8vd06fYNQhI39x9z1feK6IDtXadk0ZVqd8T0ecn1lFauWBOqA6sws6eQVNmd0grkWvVo85IjcC9S2ZI9BqmOXgNPFLU5j3lB88UAbHChzHTfMqVhzHf0w/Szmi4CNuldR+nkLJvTcwhp2IKd+gD51nWooLVFNHfCF0X9ES4tcQENWGkIOrMgXPWhlnfuaDeL7ro2cwA/b0sa66WT9TuNBi3c2czJ8vAy+gHfNDyhiLJHR1hZOf7QvMsyCpmqn/jM5By9IlRuEnACJVUhRqlIx8uWFhCF42UnVkFEgWS9VgtzSPEKxuVZDyTDqREJMUqOQQe5LQBMVAhOFBlF8qoa6KqORIMcu0NDoAVq/iH49/ATSOpjSs+gowt5psMGrI2bswSgPqoKgJjRn7lLdX6Q7szCgW45xWi6hwSiiO/QVaKX5fzXsmtOFFDcOvfWLmV+0wTI+mZZFD5i7t2IuzLGrjWg3gb5drGXRA+gak3noGl3aAKBjvkVJgYEjzUl3t7LddMDG8CzoYryOVaYvh7NjvknR+skiTeIPVwNOOhZdnNDxyPDKWWNG9AXnxx5aHh1AFvmNnDkw8lIxPxgP1HOMFPyRGfObbuK/KKeBmao3tlDdtsGDeOYK1cLBbFl/gUPGNdFTGbF6XB4uQqrZG54OVa8MaANwyUlTDkPMC3Ozapfcjy2YWXa3kg0hkyDuYlIEhzkaBKtWcBuOmT9uk1dMamGt8oPY4lPh+uUH7BtL2hshkw/HakerKvRzYLGoAFOVR9p+cX89Qdz1lNwE6g2Sa/JeyB11rgzeta1KT8xZlMA2zoUWndSzex080Eg7mDWTQdaPSAW9fzsgUwal1Yh6Ds0MfQ6RGlUaitNeXPoqR5W/Qw2pkbWhICm5bF3Kx8giaqYhNbrosY3zc1FVxTmPR5eaI9+kfEBHaobSHg7d8nmvgbpAJ+iQSliFov8VQh5DfYJ9lYArz+CxLzfDFjIjLrtT9bB3N/WVJ2hmVtXRkY/Ac1da1qFvZiCDnIMpKT3M7Vx9g4y4LncwI2WEqWLTd10AJw+M82wwFMr7Tp7dHYZiF4iV9hXMHRZRni1wgNNRdujkahA4WEMsoLqAQtegNAyxLMEoUl2AoXFJh8GoJWz3JlFvaPTOMGw3Jzgij6v3Z8+ru42HCQ4SmqtS6yIROo6D0uyrUkHGpFmojVlGQeksq5JmxvRiqBveIylVetGYiP0EKfa3bnmUIiWVUH2AlDplbUruf4CUOrlvKoPMT0pTBjEVjOYnpSkYmUprs5PSltYMRcjZSVEjVT3wAfXl2tlJ6V+tL2zPTcpQ2Na3AMxNytACoG+WmJmUqVlCVDb6UzUzKWNbCfflrj3nYl5SvBdE4/ZqWpXmJWVpVdI1dc1KytrUpWl/m5MU78bXtr+5Ngp6AEm5oYAmeiQ9HUmxIaBZMDXjOzafTgY/N2ZMIoo23Q8cUAfbdN0bmqeAB7mWhuZFS8k6uPV7NODWb4m+Omr0B4cmeaFinU8lucHpOMF3HrxYBDxML7/miIpc3f/AYR64HCsemWcFxxx7+s4DYvJRutO3HKXrHDr0rUWlQ4dHR5HtHM/0KFhTjmfOd5B1KeZphLhGUs+BtyO/0hn3MUd+u4ejlz4OR68K6fKEcYej/R8jl9s9qvFymsiJ4WnnbEP5ZPuEA/eL3tUE1ylXE8illN3EWY87d118xyUOf5B0C8ffcN3FYnAxyDN1OIO5WJ17F6n4uRhkeIXKcpOCQhGkm96jiT9naHjZzBK5bKb/zDP1at1V1/Jcm/2jVb4lbB8fuJZn8ZUXGP0gGXn71BvzXPX0xjdeirX4yuvDfuB80dqH7vKLg71K6gfYfexKOoavu7yPELJrDi8ym2O5LxK1/vochhdC/i6ff/ht/AeTm1/dJrEzIwAAAABJRU5ErkJggg==',
                                        width: 40.0,
                                        height: 40.0,
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          mainAxisSize: MainAxisSize.max,
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              'Sarah Johnson',
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                        font: GoogleFonts.inter(
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodyMedium
                                                                  .fontStyle,
                                                        ),
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .bodyMedium
                                                                .fontStyle,
                                                      ),
                                            ),
                                            Text(
                                              '2h ago',
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .labelSmall
                                                      .override(
                                                        font: GoogleFonts.inter(
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelSmall
                                                                  .fontStyle,
                                                        ),
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .secondaryText,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontWeight,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelSmall
                                                                .fontStyle,
                                                      ),
                                            ),
                                          ],
                                        ),
                                        Text(
                                          'Congratulations on this amazing achievement! Your dedication and hard work really paid off. So inspiring to see!',
                                          style: FlutterFlowTheme.of(context)
                                              .bodySmall
                                              .override(
                                                font: GoogleFonts.inter(
                                                  fontWeight:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .bodySmall
                                                          .fontWeight,
                                                  fontStyle:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .bodySmall
                                                          .fontStyle,
                                                ),
                                                letterSpacing: 0.0,
                                                fontWeight:
                                                    FlutterFlowTheme.of(context)
                                                        .bodySmall
                                                        .fontWeight,
                                                fontStyle:
                                                    FlutterFlowTheme.of(context)
                                                        .bodySmall
                                                        .fontStyle,
                                              ),
                                        ),
                                      ].divide(SizedBox(height: 4.0)),
                                    ),
                                  ),
                                ].divide(SizedBox(width: 12.0)),
                              );
                            }).divide(SizedBox(height: 12.0)),
                          );
                        },
                      ),
                    ].divide(SizedBox(height: 16.0)),
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(12.0, 12.0, 12.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          AuthUserStreamWidget(
                            builder: (context) => Container(
                              width: 50.0,
                              height: 50.0,
                              clipBehavior: Clip.antiAlias,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                              ),
                              child: Image.network(
                                currentUserPhoto,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) =>
                                    Image.asset(
                                  'assets/images/error_image.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  8.0, 0.0, 0.0, 0.0),
                              child: TextFormField(
                                controller: _model.textController,
                                focusNode: _model.textFieldFocusNode,
                                onChanged: (_) => EasyDebounce.debounce(
                                  '_model.textController',
                                  Duration(milliseconds: 2000),
                                  () => safeSetState(() {}),
                                ),
                                autofocus: true,
                                obscureText: false,
                                decoration: InputDecoration(
                                  hintText: 'Write something...',
                                  hintStyle: FlutterFlowTheme.of(context)
                                      .labelSmall
                                      .override(
                                        font: GoogleFonts.inter(
                                          fontWeight:
                                              FlutterFlowTheme.of(context)
                                                  .labelSmall
                                                  .fontWeight,
                                          fontStyle:
                                              FlutterFlowTheme.of(context)
                                                  .labelSmall
                                                  .fontStyle,
                                        ),
                                        letterSpacing: 0.0,
                                        fontWeight: FlutterFlowTheme.of(context)
                                            .labelSmall
                                            .fontWeight,
                                        fontStyle: FlutterFlowTheme.of(context)
                                            .labelSmall
                                            .fontStyle,
                                      ),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color:
                                          FlutterFlowTheme.of(context).primary,
                                      width: 1.0,
                                    ),
                                    borderRadius: const BorderRadius.only(
                                      topLeft: Radius.circular(4.0),
                                      topRight: Radius.circular(4.0),
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color: Color(0x00000000),
                                      width: 1.0,
                                    ),
                                    borderRadius: const BorderRadius.only(
                                      topLeft: Radius.circular(4.0),
                                      topRight: Radius.circular(4.0),
                                    ),
                                  ),
                                  errorBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color: Color(0x00000000),
                                      width: 1.0,
                                    ),
                                    borderRadius: const BorderRadius.only(
                                      topLeft: Radius.circular(4.0),
                                      topRight: Radius.circular(4.0),
                                    ),
                                  ),
                                  focusedErrorBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color: Color(0x00000000),
                                      width: 1.0,
                                    ),
                                    borderRadius: const BorderRadius.only(
                                      topLeft: Radius.circular(4.0),
                                      topRight: Radius.circular(4.0),
                                    ),
                                  ),
                                  contentPadding:
                                      EdgeInsetsDirectional.fromSTEB(
                                          16.0, 4.0, 8.0, 12.0),
                                ),
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      font: GoogleFonts.inter(
                                        fontWeight: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .fontWeight,
                                        fontStyle: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .fontStyle,
                                      ),
                                      letterSpacing: 0.0,
                                      fontWeight: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .fontWeight,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .fontStyle,
                                    ),
                                maxLines: 8,
                                minLines: 3,
                                validator: _model.textControllerValidator
                                    .asValidator(context),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Divider(
                      height: 12.0,
                      thickness: 2.0,
                      color: FlutterFlowTheme.of(context).alternate,
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(12.0, 4.0, 12.0, 12.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 0.0, 4.0, 0.0),
                                child: FlutterFlowIconButton(
                                  borderColor: Colors.transparent,
                                  borderRadius: 30.0,
                                  borderWidth: 1.0,
                                  buttonSize: 40.0,
                                  icon: Icon(
                                    Icons.photo_outlined,
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryText,
                                    size: 20.0,
                                  ),
                                  onPressed: () {
                                    print('IconButton pressed ...');
                                  },
                                ),
                              ),
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 0.0, 4.0, 0.0),
                                child: FlutterFlowIconButton(
                                  borderColor: Colors.transparent,
                                  borderRadius: 30.0,
                                  borderWidth: 1.0,
                                  buttonSize: 40.0,
                                  icon: Icon(
                                    Icons.emoji_emotions_outlined,
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryText,
                                    size: 20.0,
                                  ),
                                  onPressed: () {
                                    print('IconButton pressed ...');
                                  },
                                ),
                              ),
                            ],
                          ),
                          FFButtonWidget(
                            onPressed: () async {
                              Navigator.pop(context);
                            },
                            text: 'Post',
                            options: FFButtonOptions(
                              width: 90.0,
                              height: 40.0,
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              iconPadding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              color: FlutterFlowTheme.of(context).primary,
                              textStyle: FlutterFlowTheme.of(context)
                                  .titleSmall
                                  .override(
                                    font: GoogleFonts.interTight(
                                      fontWeight: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .fontWeight,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .fontStyle,
                                    ),
                                    color: Colors.white,
                                    letterSpacing: 0.0,
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .fontStyle,
                                  ),
                              elevation: 2.0,
                              borderSide: BorderSide(
                                color: Colors.transparent,
                                width: 1.0,
                              ),
                              borderRadius: BorderRadius.circular(12.0),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
