import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:async';
import 'dart:ui';
import '/index.dart';
import 'edit_profile_auth2_widget.dart' show EditProfileAuth2Widget;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class EditProfileAuth2Model extends FlutterFlowModel<EditProfileAuth2Widget> {
  ///  State fields for stateful widgets in this component.

  final formKey = GlobalKey<FormState>();
  bool isDataUploading_uploadData8ss = false;
  FFUploadedFile uploadedLocalFile_uploadData8ss =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl_uploadData8ss = '';

  // State field(s) for yourName widget.
  FocusNode? yourNameFocusNode;
  TextEditingController? yourNameTextController;
  String? Function(BuildContext, String?)? yourNameTextControllerValidator;
  // State field(s) for DropDownRace widget.
  String? dropDownRaceValue;
  FormFieldController<String>? dropDownRaceValueController;
  // State field(s) for DropDownSex widget.
  String? dropDownSexValue;
  FormFieldController<String>? dropDownSexValueController;
  // State field(s) for DropDownRelationship widget.
  String? dropDownRelationshipValue;
  FormFieldController<String>? dropDownRelationshipValueController;
  // State field(s) for Age widget.
  FocusNode? ageFocusNode;
  TextEditingController? ageTextController;
  String? Function(BuildContext, String?)? ageTextControllerValidator;
  // State field(s) for Ethnicity widget.
  FocusNode? ethnicityFocusNode;
  TextEditingController? ethnicityTextController;
  String? Function(BuildContext, String?)? ethnicityTextControllerValidator;
  // State field(s) for Religion widget.
  FocusNode? religionFocusNode;
  TextEditingController? religionTextController;
  String? Function(BuildContext, String?)? religionTextControllerValidator;
  DateTime? datePicked;
  // State field(s) for City widget.
  FocusNode? cityFocusNode;
  TextEditingController? cityTextController;
  String? Function(BuildContext, String?)? cityTextControllerValidator;
  // State field(s) for Hobbies widget.
  FocusNode? hobbiesFocusNode;
  TextEditingController? hobbiesTextController;
  String? Function(BuildContext, String?)? hobbiesTextControllerValidator;
  // State field(s) for DreamRide widget.
  FocusNode? dreamRideFocusNode;
  TextEditingController? dreamRideTextController;
  String? Function(BuildContext, String?)? dreamRideTextControllerValidator;
  // State field(s) for FavouriteTracks widget.
  FocusNode? favouriteTracksFocusNode;
  TextEditingController? favouriteTracksTextController;
  String? Function(BuildContext, String?)?
      favouriteTracksTextControllerValidator;
  // State field(s) for FutureMods widget.
  FocusNode? futureModsFocusNode;
  TextEditingController? futureModsTextController;
  String? Function(BuildContext, String?)? futureModsTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    yourNameFocusNode?.dispose();
    yourNameTextController?.dispose();

    ageFocusNode?.dispose();
    ageTextController?.dispose();

    ethnicityFocusNode?.dispose();
    ethnicityTextController?.dispose();

    religionFocusNode?.dispose();
    religionTextController?.dispose();

    cityFocusNode?.dispose();
    cityTextController?.dispose();

    hobbiesFocusNode?.dispose();
    hobbiesTextController?.dispose();

    dreamRideFocusNode?.dispose();
    dreamRideTextController?.dispose();

    favouriteTracksFocusNode?.dispose();
    favouriteTracksTextController?.dispose();

    futureModsFocusNode?.dispose();
    futureModsTextController?.dispose();
  }
}
