import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'new_post_model.dart';
export 'new_post_model.dart';

class NewPostWidget extends StatefulWidget {
  const NewPostWidget({super.key});

  static String routeName = 'newPost';
  static String routePath = '/newPost';

  @override
  State<NewPostWidget> createState() => _NewPostWidgetState();
}

class _NewPostWidgetState extends State<NewPostWidget> {
  late NewPostModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NewPostModel());

    _model.captionTextController ??= TextEditingController();
    _model.captionFocusNode ??= FocusNode();
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
      appBar: AppBar(
        backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
        automaticallyImplyLeading: false,
        title: FFButtonWidget(
          onPressed: () async {
            context.pop();
          },
          text: 'Cancel',
          options: FFButtonOptions(
            width: 80.0,
            height: 40.0,
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
            iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
            color: FlutterFlowTheme.of(context).secondaryBackground,
            textStyle: FlutterFlowTheme.of(context).labelMedium.override(
                  font: GoogleFonts.inter(
                    fontWeight:
                        FlutterFlowTheme.of(context).labelMedium.fontWeight,
                    fontStyle:
                        FlutterFlowTheme.of(context).labelMedium.fontStyle,
                  ),
                  letterSpacing: 0.0,
                  fontWeight:
                      FlutterFlowTheme.of(context).labelMedium.fontWeight,
                  fontStyle: FlutterFlowTheme.of(context).labelMedium.fontStyle,
                ),
            elevation: 0.0,
            borderSide: BorderSide(
              color: Colors.transparent,
              width: 1.0,
            ),
          ),
        ),
        actions: [
          Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 16.0, 8.0),
            child: FFButtonWidget(
              onPressed: () async {
                var postsRecordReference = PostsRecord.collection.doc();
                await postsRecordReference.set({
                  ...createPostsRecordData(
                    postPhoto: _model.uploadedFileUrl_uploadDataXbf,
                    postDescription: _model.captionTextController.text,
                    postUser: currentUserReference,
                  ),
                  ...mapToFirestore(
                    {
                      'time_posted': FieldValue.serverTimestamp(),
                    },
                  ),
                });
                _model.post = PostsRecord.getDocumentFromData({
                  ...createPostsRecordData(
                    postPhoto: _model.uploadedFileUrl_uploadDataXbf,
                    postDescription: _model.captionTextController.text,
                    postUser: currentUserReference,
                  ),
                  ...mapToFirestore(
                    {
                      'time_posted': DateTime.now(),
                    },
                  ),
                }, postsRecordReference);
                context.safePop();

                safeSetState(() {});
              },
              text: 'Send',
              options: FFButtonOptions(
                width: 70.0,
                height: 32.0,
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                color: FlutterFlowTheme.of(context).primary,
                textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                      font: GoogleFonts.interTight(
                        fontWeight:
                            FlutterFlowTheme.of(context).titleSmall.fontWeight,
                        fontStyle:
                            FlutterFlowTheme.of(context).titleSmall.fontStyle,
                      ),
                      color: Colors.white,
                      letterSpacing: 0.0,
                      fontWeight:
                          FlutterFlowTheme.of(context).titleSmall.fontWeight,
                      fontStyle:
                          FlutterFlowTheme.of(context).titleSmall.fontStyle,
                    ),
                elevation: 2.0,
                borderSide: BorderSide(
                  color: Colors.transparent,
                  width: 1.0,
                ),
              ),
            ),
          ),
        ],
        centerTitle: false,
        elevation: 0.0,
      ),
      body: SafeArea(
        top: true,
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(24.0, 12.0, 24.0, 0.0),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Card(
                    clipBehavior: Clip.antiAliasWithSaveLayer,
                    color: FlutterFlowTheme.of(context).secondary,
                    elevation: 2.0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(50.0),
                    ),
                    child: Padding(
                      padding: EdgeInsets.all(2.0),
                      child: AuthUserStreamWidget(
                        builder: (context) => Container(
                          width: 40.0,
                          height: 40.0,
                          clipBehavior: Clip.antiAlias,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                          ),
                          child: Image.network(
                            valueOrDefault<String>(
                              currentUserPhoto,
                              'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJQAAACUCAMAAABC4vDmAAAAY1BMVEX///8AAADR0dHl5eX29vbi4uLw8PCqqqp0dHTt7e3a2tr8/Pw/Pz+UlJTz8/NlZWWEhIQxMTE6OjpcXFyOjo4ODg5GRkbFxcVUVFSwsLAcHBwhISFLS0u8vLyioqIXFxcpKSkQ0Ih2AAAHbElEQVR4nO1c2baiOhRUBhkUAVFx1v//ytuezk4CZKhA8LjW7XrrPhKKZGfPyWLxD/9nrFdhnOcBQ57H4Wr9q4TiNimq8lg/lxzP+lhWRdLGv0Joe05v9WWpwaW+peftRwnFQVXr6Mio98GHZiy6V0eE0V8cq3s0N6N1VtUHnNIbh7rK5hT9bVu6ESKU7WzylTTjKP3QSuZgFN13inc9680pLc5tHmZRlIV5ey7S00bWERw778K1bm+Dt7yafdJmql9nbbJvroMHbq1X2YrTvnQf0jZXEuLE8lbxkD8NET16Y2/SHHsyTzc9Yg9Pa9h25fuQ3h220vaedgWsaX1wenQHrXLHb43yqjPAdfo+jE/ygLti1OxHRWfnNhMlK5Bt3KsYPVpcyJuxDqZwSuSlK8MpQ4WyMbicR48TycLQTPq6NwJ5w1Qjd+EqlbZc4cF4bQuJVboaM0Qk6fDN5Gn6i2AjxjyNmKtMPH9I/VB6Q9LyG6NFUHISquDg08CvE8Hq5MgqEvP0BE0KilyaK6cVXIl5aiYpAhVCMfjJQdojse9K54W3IxMqK8WdmWrMQw5YC1YV+kwyWcXZIKllcBcF3Laks0VHEZ+rC6QCY26DyxkjI7GCNWLl+d5onGR8vd06fYNQhI39x9z1feK6IDtXadk0ZVqd8T0ecn1lFauWBOqA6sws6eQVNmd0grkWvVo85IjcC9S2ZI9BqmOXgNPFLU5j3lB88UAbHChzHTfMqVhzHf0w/Szmi4CNuldR+nkLJvTcwhp2IKd+gD51nWooLVFNHfCF0X9ES4tcQENWGkIOrMgXPWhlnfuaDeL7ro2cwA/b0sa66WT9TuNBi3c2czJ8vAy+gHfNDyhiLJHR1hZOf7QvMsyCpmqn/jM5By9IlRuEnACJVUhRqlIx8uWFhCF42UnVkFEgWS9VgtzSPEKxuVZDyTDqREJMUqOQQe5LQBMVAhOFBlF8qoa6KqORIMcu0NDoAVq/iH49/ATSOpjSs+gowt5psMGrI2bswSgPqoKgJjRn7lLdX6Q7szCgW45xWi6hwSiiO/QVaKX5fzXsmtOFFDcOvfWLmV+0wTI+mZZFD5i7t2IuzLGrjWg3gb5drGXRA+gak3noGl3aAKBjvkVJgYEjzUl3t7LddMDG8CzoYryOVaYvh7NjvknR+skiTeIPVwNOOhZdnNDxyPDKWWNG9AXnxx5aHh1AFvmNnDkw8lIxPxgP1HOMFPyRGfObbuK/KKeBmao3tlDdtsGDeOYK1cLBbFl/gUPGNdFTGbF6XB4uQqrZG54OVa8MaANwyUlTDkPMC3Ozapfcjy2YWXa3kg0hkyDuYlIEhzkaBKtWcBuOmT9uk1dMamGt8oPY4lPh+uUH7BtL2hshkw/HakerKvRzYLGoAFOVR9p+cX89Qdz1lNwE6g2Sa/JeyB11rgzeta1KT8xZlMA2zoUWndSzex080Eg7mDWTQdaPSAW9fzsgUwal1Yh6Ds0MfQ6RGlUaitNeXPoqR5W/Qw2pkbWhICm5bF3Kx8giaqYhNbrosY3zc1FVxTmPR5eaI9+kfEBHaobSHg7d8nmvgbpAJ+iQSliFov8VQh5DfYJ9lYArz+CxLzfDFjIjLrtT9bB3N/WVJ2hmVtXRkY/Ac1da1qFvZiCDnIMpKT3M7Vx9g4y4LncwI2WEqWLTd10AJw+M82wwFMr7Tp7dHYZiF4iV9hXMHRZRni1wgNNRdujkahA4WEMsoLqAQtegNAyxLMEoUl2AoXFJh8GoJWz3JlFvaPTOMGw3Jzgij6v3Z8+ru42HCQ4SmqtS6yIROo6D0uyrUkHGpFmojVlGQeksq5JmxvRiqBveIylVetGYiP0EKfa3bnmUIiWVUH2AlDplbUruf4CUOrlvKoPMT0pTBjEVjOYnpSkYmUprs5PSltYMRcjZSVEjVT3wAfXl2tlJ6V+tL2zPTcpQ2Na3AMxNytACoG+WmJmUqVlCVDb6UzUzKWNbCfflrj3nYl5SvBdE4/ZqWpXmJWVpVdI1dc1KytrUpWl/m5MU78bXtr+5Ngp6AEm5oYAmeiQ9HUmxIaBZMDXjOzafTgY/N2ZMIoo23Q8cUAfbdN0bmqeAB7mWhuZFS8k6uPV7NODWb4m+Omr0B4cmeaFinU8lucHpOMF3HrxYBDxML7/miIpc3f/AYR64HCsemWcFxxx7+s4DYvJRutO3HKXrHDr0rUWlQ4dHR5HtHM/0KFhTjmfOd5B1KeZphLhGUs+BtyO/0hn3MUd+u4ejlz4OR68K6fKEcYej/R8jl9s9qvFymsiJ4WnnbEP5ZPuEA/eL3tUE1ylXE8illN3EWY87d118xyUOf5B0C8ffcN3FYnAxyDN1OIO5WJ17F6n4uRhkeIXKcpOCQhGkm96jiT9naHjZzBK5bKb/zDP1at1V1/Jcm/2jVb4lbB8fuJZn8ZUXGP0gGXn71BvzXPX0xjdeirX4yuvDfuB80dqH7vKLg71K6gfYfexKOoavu7yPELJrDi8ym2O5LxK1/vochhdC/i6ff/ht/AeTm1/dJrEzIwAAAABJRU5ErkJggg==',
                            ),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 0.0, 0.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        AuthUserStreamWidget(
                          builder: (context) => Text(
                            valueOrDefault<String>(
                              currentUserDisplayName,
                              'Username',
                            ),
                            style: FlutterFlowTheme.of(context)
                                .titleLarge
                                .override(
                                  font: GoogleFonts.interTight(
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .titleLarge
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .titleLarge
                                        .fontStyle,
                                  ),
                                  letterSpacing: 0.0,
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .titleLarge
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .titleLarge
                                      .fontStyle,
                                ),
                          ),
                        ),
                        Text(
                          currentUserEmail,
                          style:
                              FlutterFlowTheme.of(context).labelMedium.override(
                                    font: GoogleFonts.inter(
                                      fontWeight: FlutterFlowTheme.of(context)
                                          .labelMedium
                                          .fontWeight,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .labelMedium
                                          .fontStyle,
                                    ),
                                    letterSpacing: 0.0,
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .labelMedium
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .labelMedium
                                        .fontStyle,
                                  ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              decoration: BoxDecoration(),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(10.0, 12.0, 10.0, 12.0),
                child: TextFormField(
                  controller: _model.captionTextController,
                  focusNode: _model.captionFocusNode,
                  onChanged: (_) => EasyDebounce.debounce(
                    '_model.captionTextController',
                    Duration(milliseconds: 2000),
                    () => safeSetState(() {}),
                  ),
                  autofocus: true,
                  textCapitalization: TextCapitalization.sentences,
                  obscureText: false,
                  decoration: InputDecoration(
                    hintText: 'What\'s happening?',
                    hintStyle: FlutterFlowTheme.of(context).labelLarge.override(
                          font: GoogleFonts.inter(
                            fontWeight: FlutterFlowTheme.of(context)
                                .labelLarge
                                .fontWeight,
                            fontStyle: FlutterFlowTheme.of(context)
                                .labelLarge
                                .fontStyle,
                          ),
                          letterSpacing: 0.0,
                          fontWeight: FlutterFlowTheme.of(context)
                              .labelLarge
                              .fontWeight,
                          fontStyle:
                              FlutterFlowTheme.of(context).labelLarge.fontStyle,
                        ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: FlutterFlowTheme.of(context).error,
                        width: 1.0,
                      ),
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(4.0),
                        topRight: Radius.circular(4.0),
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: FlutterFlowTheme.of(context).primary,
                        width: 1.0,
                      ),
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(4.0),
                        topRight: Radius.circular(4.0),
                      ),
                    ),
                    errorBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: FlutterFlowTheme.of(context).error,
                        width: 1.0,
                      ),
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(4.0),
                        topRight: Radius.circular(4.0),
                      ),
                    ),
                    focusedErrorBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: FlutterFlowTheme.of(context).error,
                        width: 1.0,
                      ),
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(4.0),
                        topRight: Radius.circular(4.0),
                      ),
                    ),
                    contentPadding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 8.0, 16.0, 12.0),
                  ),
                  style: FlutterFlowTheme.of(context).bodyLarge.override(
                        font: GoogleFonts.inter(
                          fontWeight:
                              FlutterFlowTheme.of(context).bodyLarge.fontWeight,
                          fontStyle:
                              FlutterFlowTheme.of(context).bodyLarge.fontStyle,
                        ),
                        letterSpacing: 0.0,
                        fontWeight:
                            FlutterFlowTheme.of(context).bodyLarge.fontWeight,
                        fontStyle:
                            FlutterFlowTheme.of(context).bodyLarge.fontStyle,
                      ),
                  textAlign: TextAlign.start,
                  maxLines: 7,
                  cursorColor: FlutterFlowTheme.of(context).primary,
                  validator: _model.captionTextControllerValidator
                      .asValidator(context),
                  inputFormatters: [
                    if (!isAndroid && !isiOS)
                      TextInputFormatter.withFunction((oldValue, newValue) {
                        return TextEditingValue(
                          selection: newValue.selection,
                          text: newValue.text
                              .toCapitalization(TextCapitalization.sentences),
                        );
                      }),
                  ],
                ),
              ),
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8.0),
                child: Image.network(
                  _model.uploadedFileUrl_uploadDataXbf,
                  width: double.infinity,
                  height: 170.0,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Align(
              alignment: AlignmentDirectional(-1.0, 0.0),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(12.0, 12.0, 0.0, 0.0),
                child: Text(
                  'Upload a Victory Photo',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        font: GoogleFonts.inter(
                          fontWeight: FontWeight.w600,
                          fontStyle:
                              FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                        ),
                        fontSize: 17.0,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.w600,
                        fontStyle:
                            FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                      ),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(16.0, 12.0, 16.0, 0.0),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 12.0, 0.0),
                    child: StreamBuilder<List<PostsRecord>>(
                      stream: queryPostsRecord(),
                      builder: (context, snapshot) {
                        // Customize what your widget looks like when it's loading.
                        if (!snapshot.hasData) {
                          return Center(
                            child: SizedBox(
                              width: 50.0,
                              height: 50.0,
                              child: CircularProgressIndicator(
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  FlutterFlowTheme.of(context).primary,
                                ),
                              ),
                            ),
                          );
                        }
                        List<PostsRecord> iconButtonPostsRecordList =
                            snapshot.data!;

                        return FlutterFlowIconButton(
                          borderColor: Colors.transparent,
                          borderRadius: 30.0,
                          borderWidth: 1.0,
                          buttonSize: 60.0,
                          icon: Icon(
                            Icons.add_photo_alternate_outlined,
                            color: FlutterFlowTheme.of(context).primary,
                            size: 32.0,
                          ),
                          onPressed: () async {
                            final selectedMedia =
                                await selectMediaWithSourceBottomSheet(
                              context: context,
                              allowPhoto: true,
                              textColor: FlutterFlowTheme.of(context).primary,
                            );
                            if (selectedMedia != null &&
                                selectedMedia.every((m) => validateFileFormat(
                                    m.storagePath, context))) {
                              safeSetState(() =>
                                  _model.isDataUploading_uploadDataXbf = true);
                              var selectedUploadedFiles = <FFUploadedFile>[];

                              var downloadUrls = <String>[];
                              try {
                                selectedUploadedFiles = selectedMedia
                                    .map((m) => FFUploadedFile(
                                          name: m.storagePath.split('/').last,
                                          bytes: m.bytes,
                                          height: m.dimensions?.height,
                                          width: m.dimensions?.width,
                                          blurHash: m.blurHash,
                                        ))
                                    .toList();

                                downloadUrls = (await Future.wait(
                                  selectedMedia.map(
                                    (m) async => await uploadData(
                                        m.storagePath, m.bytes),
                                  ),
                                ))
                                    .where((u) => u != null)
                                    .map((u) => u!)
                                    .toList();
                              } finally {
                                _model.isDataUploading_uploadDataXbf = false;
                              }
                              if (selectedUploadedFiles.length ==
                                      selectedMedia.length &&
                                  downloadUrls.length == selectedMedia.length) {
                                safeSetState(() {
                                  _model.uploadedLocalFile_uploadDataXbf =
                                      selectedUploadedFiles.first;
                                  _model.uploadedFileUrl_uploadDataXbf =
                                      downloadUrls.first;
                                });
                              } else {
                                safeSetState(() {});
                                return;
                              }
                            }

                            _model.uploadedImageUrl = _model.uploadedImageUrl;
                            safeSetState(() {});
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
