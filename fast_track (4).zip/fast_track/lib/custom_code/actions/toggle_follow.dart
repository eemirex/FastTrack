// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
import 'package:cloud_firestore/cloud_firestore.dart';

Future toggleFollow(String followerId, String followedId) async {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  final followerRef = firestore.collection('Users').doc(followerId);
  final followedRef = firestore.collection('Users').doc(followedId);

  final followerDoc = await followerRef.get();
  final followedDoc = await followedRef.get();

  final followingList =
      List<String>.from(followerDoc.data()?['following'] ?? []);
  final followersList =
      List<String>.from(followedDoc.data()?['followers'] ?? []);

  final isAlreadyFollowing = followingList.contains(followedId);

  if (isAlreadyFollowing) {
    // UNFOLLOW
    await followerRef.update({
      'following': FieldValue.arrayRemove([followedId]),
    });
    await followedRef.update({
      'followers': FieldValue.arrayRemove([followerId]),
    });
  } else {
    // FOLLOW
    await followerRef.update({
      'following': FieldValue.arrayUnion([followedId]),
    });
    await followedRef.update({
      'followers': FieldValue.arrayUnion([followerId]),
    });
  }
}
