import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAwLUCzhfL69i0Ke7rJDv4oboupHEDPShE",
            authDomain: "fasttrack-fb478.firebaseapp.com",
            projectId: "fasttrack-fb478",
            storageBucket: "fasttrack-fb478.firebasestorage.app",
            messagingSenderId: "179307023127",
            appId: "1:179307023127:web:777867f382819992fc8552",
            measurementId: "G-ZF3BPY6ET4"));
  } else {
    await Firebase.initializeApp();
  }
}
