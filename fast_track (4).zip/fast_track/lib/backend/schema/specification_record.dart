import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SpecificationRecord extends FirestoreRecord {
  SpecificationRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "year_make_model" field.
  String? _yearMakeModel;
  String get yearMakeModel => _yearMakeModel ?? '';
  bool hasYearMakeModel() => _yearMakeModel != null;

  // "modifications" field.
  String? _modifications;
  String get modifications => _modifications ?? '';
  bool hasModifications() => _modifications != null;

  void _initializeFields() {
    _yearMakeModel = snapshotData['year_make_model'] as String?;
    _modifications = snapshotData['modifications'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('specification');

  static Stream<SpecificationRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SpecificationRecord.fromSnapshot(s));

  static Future<SpecificationRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SpecificationRecord.fromSnapshot(s));

  static SpecificationRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SpecificationRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SpecificationRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SpecificationRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SpecificationRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SpecificationRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSpecificationRecordData({
  String? yearMakeModel,
  String? modifications,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'year_make_model': yearMakeModel,
      'modifications': modifications,
    }.withoutNulls,
  );

  return firestoreData;
}

class SpecificationRecordDocumentEquality
    implements Equality<SpecificationRecord> {
  const SpecificationRecordDocumentEquality();

  @override
  bool equals(SpecificationRecord? e1, SpecificationRecord? e2) {
    return e1?.yearMakeModel == e2?.yearMakeModel &&
        e1?.modifications == e2?.modifications;
  }

  @override
  int hash(SpecificationRecord? e) =>
      const ListEquality().hash([e?.yearMakeModel, e?.modifications]);

  @override
  bool isValidKey(Object? o) => o is SpecificationRecord;
}
