import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_expanded_image_view.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'my_rides_model.dart';
export 'my_rides_model.dart';

class MyRidesWidget extends StatefulWidget {
  const MyRidesWidget({
    super.key,
    this.user,
  });

  final UserRecord? user;

  static String routeName = 'myRides';
  static String routePath = '/myRides';

  @override
  State<MyRidesWidget> createState() => _MyRidesWidgetState();
}

class _MyRidesWidgetState extends State<MyRidesWidget> {
  late MyRidesModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MyRidesModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: Color(0xFF171718),
        appBar: AppBar(
          backgroundColor: Color(0xFFFF1200),
          automaticallyImplyLeading: false,
          title: Text(
            'My Rides',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  font: GoogleFonts.interTight(
                    fontWeight:
                        FlutterFlowTheme.of(context).headlineMedium.fontWeight,
                    fontStyle:
                        FlutterFlowTheme.of(context).headlineMedium.fontStyle,
                  ),
                  color: Colors.white,
                  fontSize: 28.0,
                  letterSpacing: 0.0,
                  fontWeight:
                      FlutterFlowTheme.of(context).headlineMedium.fontWeight,
                  fontStyle:
                      FlutterFlowTheme.of(context).headlineMedium.fontStyle,
                ),
          ),
          actions: [
            FlutterFlowIconButton(
              buttonSize: 48.0,
              icon: Icon(
                Icons.settings_outlined,
                color: Colors.white,
                size: 24.0,
              ),
              onPressed: () async {
                context.pushNamed(SettingsWidget.routeName);
              },
            ),
          ],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Align(
            alignment: AlignmentDirectional(0.0, 0.0),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: MediaQuery.sizeOf(context).width * 0.95,
                    height: 300.0,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              20.0, 20.0, 20.0, 20.0),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Align(
                                alignment: AlignmentDirectional(0.0, -1.0),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      width: 140.0,
                                      child: Stack(
                                        children: [
                                          Align(
                                            alignment:
                                                AlignmentDirectional(0.0, 0.0),
                                            child: Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      0.0, 12.0, 0.0, 0.0),
                                              child: Container(
                                                width: 100.0,
                                                height: 100.0,
                                                decoration: BoxDecoration(
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .secondaryBackground,
                                                  shape: BoxShape.circle,
                                                  border: Border.all(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .primary,
                                                  ),
                                                ),
                                                child: Padding(
                                                  padding: EdgeInsets.all(2.0),
                                                  child: AuthUserStreamWidget(
                                                    builder: (context) =>
                                                        InkWell(
                                                      splashColor:
                                                          Colors.transparent,
                                                      focusColor:
                                                          Colors.transparent,
                                                      hoverColor:
                                                          Colors.transparent,
                                                      highlightColor:
                                                          Colors.transparent,
                                                      onTap: () async {
                                                        await Navigator.push(
                                                          context,
                                                          PageTransition(
                                                            type:
                                                                PageTransitionType
                                                                    .fade,
                                                            child:
                                                                FlutterFlowExpandedImageView(
                                                              image:
                                                                  CachedNetworkImage(
                                                                fadeInDuration:
                                                                    Duration(
                                                                        milliseconds:
                                                                            500),
                                                                fadeOutDuration:
                                                                    Duration(
                                                                        milliseconds:
                                                                            500),
                                                                imageUrl:
                                                                    valueOrDefault<
                                                                        String>(
                                                                  currentUserPhoto,
                                                                  'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJQAAACUCAMAAABC4vDmAAAAY1BMVEX///8AAADR0dHl5eX29vbi4uLw8PCqqqp0dHTt7e3a2tr8/Pw/Pz+UlJTz8/NlZWWEhIQxMTE6OjpcXFyOjo4ODg5GRkbFxcVUVFSwsLAcHBwhISFLS0u8vLyioqIXFxcpKSkQ0Ih2AAAHbElEQVR4nO1c2baiOhRUBhkUAVFx1v//ytuezk4CZKhA8LjW7XrrPhKKZGfPyWLxD/9nrFdhnOcBQ57H4Wr9q4TiNimq8lg/lxzP+lhWRdLGv0Joe05v9WWpwaW+peftRwnFQVXr6Mio98GHZiy6V0eE0V8cq3s0N6N1VtUHnNIbh7rK5hT9bVu6ESKU7WzylTTjKP3QSuZgFN13inc9680pLc5tHmZRlIV5ey7S00bWERw778K1bm+Dt7yafdJmql9nbbJvroMHbq1X2YrTvnQf0jZXEuLE8lbxkD8NET16Y2/SHHsyTzc9Yg9Pa9h25fuQ3h220vaedgWsaX1wenQHrXLHb43yqjPAdfo+jE/ygLti1OxHRWfnNhMlK5Bt3KsYPVpcyJuxDqZwSuSlK8MpQ4WyMbicR48TycLQTPq6NwJ5w1Qjd+EqlbZc4cF4bQuJVboaM0Qk6fDN5Gn6i2AjxjyNmKtMPH9I/VB6Q9LyG6NFUHISquDg08CvE8Hq5MgqEvP0BE0KilyaK6cVXIl5aiYpAhVCMfjJQdojse9K54W3IxMqK8WdmWrMQw5YC1YV+kwyWcXZIKllcBcF3Laks0VHEZ+rC6QCY26DyxkjI7GCNWLl+d5onGR8vd06fYNQhI39x9z1feK6IDtXadk0ZVqd8T0ecn1lFauWBOqA6sws6eQVNmd0grkWvVo85IjcC9S2ZI9BqmOXgNPFLU5j3lB88UAbHChzHTfMqVhzHf0w/Szmi4CNuldR+nkLJvTcwhp2IKd+gD51nWooLVFNHfCF0X9ES4tcQENWGkIOrMgXPWhlnfuaDeL7ro2cwA/b0sa66WT9TuNBi3c2czJ8vAy+gHfNDyhiLJHR1hZOf7QvMsyCpmqn/jM5By9IlRuEnACJVUhRqlIx8uWFhCF42UnVkFEgWS9VgtzSPEKxuVZDyTDqREJMUqOQQe5LQBMVAhOFBlF8qoa6KqORIMcu0NDoAVq/iH49/ATSOpjSs+gowt5psMGrI2bswSgPqoKgJjRn7lLdX6Q7szCgW45xWi6hwSiiO/QVaKX5fzXsmtOFFDcOvfWLmV+0wTI+mZZFD5i7t2IuzLGrjWg3gb5drGXRA+gak3noGl3aAKBjvkVJgYEjzUl3t7LddMDG8CzoYryOVaYvh7NjvknR+skiTeIPVwNOOhZdnNDxyPDKWWNG9AXnxx5aHh1AFvmNnDkw8lIxPxgP1HOMFPyRGfObbuK/KKeBmao3tlDdtsGDeOYK1cLBbFl/gUPGNdFTGbF6XB4uQqrZG54OVa8MaANwyUlTDkPMC3Ozapfcjy2YWXa3kg0hkyDuYlIEhzkaBKtWcBuOmT9uk1dMamGt8oPY4lPh+uUH7BtL2hshkw/HakerKvRzYLGoAFOVR9p+cX89Qdz1lNwE6g2Sa/JeyB11rgzeta1KT8xZlMA2zoUWndSzex080Eg7mDWTQdaPSAW9fzsgUwal1Yh6Ds0MfQ6RGlUaitNeXPoqR5W/Qw2pkbWhICm5bF3Kx8giaqYhNbrosY3zc1FVxTmPR5eaI9+kfEBHaobSHg7d8nmvgbpAJ+iQSliFov8VQh5DfYJ9lYArz+CxLzfDFjIjLrtT9bB3N/WVJ2hmVtXRkY/Ac1da1qFvZiCDnIMpKT3M7Vx9g4y4LncwI2WEqWLTd10AJw+M82wwFMr7Tp7dHYZiF4iV9hXMHRZRni1wgNNRdujkahA4WEMsoLqAQtegNAyxLMEoUl2AoXFJh8GoJWz3JlFvaPTOMGw3Jzgij6v3Z8+ru42HCQ4SmqtS6yIROo6D0uyrUkHGpFmojVlGQeksq5JmxvRiqBveIylVetGYiP0EKfa3bnmUIiWVUH2AlDplbUruf4CUOrlvKoPMT0pTBjEVjOYnpSkYmUprs5PSltYMRcjZSVEjVT3wAfXl2tlJ6V+tL2zPTcpQ2Na3AMxNytACoG+WmJmUqVlCVDb6UzUzKWNbCfflrj3nYl5SvBdE4/ZqWpXmJWVpVdI1dc1KytrUpWl/m5MU78bXtr+5Ngp6AEm5oYAmeiQ9HUmxIaBZMDXjOzafTgY/N2ZMIoo23Q8cUAfbdN0bmqeAB7mWhuZFS8k6uPV7NODWb4m+Omr0B4cmeaFinU8lucHpOMF3HrxYBDxML7/miIpc3f/AYR64HCsemWcFxxx7+s4DYvJRutO3HKXrHDr0rUWlQ4dHR5HtHM/0KFhTjmfOd5B1KeZphLhGUs+BtyO/0hn3MUd+u4ejlz4OR68K6fKEcYej/R8jl9s9qvFymsiJ4WnnbEP5ZPuEA/eL3tUE1ylXE8illN3EWY87d118xyUOf5B0C8ffcN3FYnAxyDN1OIO5WJ17F6n4uRhkeIXKcpOCQhGkm96jiT9naHjZzBK5bKb/zDP1at1V1/Jcm/2jVb4lbB8fuJZn8ZUXGP0gGXn71BvzXPX0xjdeirX4yuvDfuB80dqH7vKLg71K6gfYfexKOoavu7yPELJrDi8ym2O5LxK1/vochhdC/i6ff/ht/AeTm1/dJrEzIwAAAABJRU5ErkJggg==',
                                                                ),
                                                                fit: BoxFit
                                                                    .contain,
                                                              ),
                                                              allowRotation:
                                                                  true,
                                                              tag:
                                                                  valueOrDefault<
                                                                      String>(
                                                                currentUserPhoto,
                                                                'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJQAAACUCAMAAABC4vDmAAAAY1BMVEX///8AAADR0dHl5eX29vbi4uLw8PCqqqp0dHTt7e3a2tr8/Pw/Pz+UlJTz8/NlZWWEhIQxMTE6OjpcXFyOjo4ODg5GRkbFxcVUVFSwsLAcHBwhISFLS0u8vLyioqIXFxcpKSkQ0Ih2AAAHbElEQVR4nO1c2baiOhRUBhkUAVFx1v//ytuezk4CZKhA8LjW7XrrPhKKZGfPyWLxD/9nrFdhnOcBQ57H4Wr9q4TiNimq8lg/lxzP+lhWRdLGv0Joe05v9WWpwaW+peftRwnFQVXr6Mio98GHZiy6V0eE0V8cq3s0N6N1VtUHnNIbh7rK5hT9bVu6ESKU7WzylTTjKP3QSuZgFN13inc9680pLc5tHmZRlIV5ey7S00bWERw778K1bm+Dt7yafdJmql9nbbJvroMHbq1X2YrTvnQf0jZXEuLE8lbxkD8NET16Y2/SHHsyTzc9Yg9Pa9h25fuQ3h220vaedgWsaX1wenQHrXLHb43yqjPAdfo+jE/ygLti1OxHRWfnNhMlK5Bt3KsYPVpcyJuxDqZwSuSlK8MpQ4WyMbicR48TycLQTPq6NwJ5w1Qjd+EqlbZc4cF4bQuJVboaM0Qk6fDN5Gn6i2AjxjyNmKtMPH9I/VB6Q9LyG6NFUHISquDg08CvE8Hq5MgqEvP0BE0KilyaK6cVXIl5aiYpAhVCMfjJQdojse9K54W3IxMqK8WdmWrMQw5YC1YV+kwyWcXZIKllcBcF3Laks0VHEZ+rC6QCY26DyxkjI7GCNWLl+d5onGR8vd06fYNQhI39x9z1feK6IDtXadk0ZVqd8T0ecn1lFauWBOqA6sws6eQVNmd0grkWvVo85IjcC9S2ZI9BqmOXgNPFLU5j3lB88UAbHChzHTfMqVhzHf0w/Szmi4CNuldR+nkLJvTcwhp2IKd+gD51nWooLVFNHfCF0X9ES4tcQENWGkIOrMgXPWhlnfuaDeL7ro2cwA/b0sa66WT9TuNBi3c2czJ8vAy+gHfNDyhiLJHR1hZOf7QvMsyCpmqn/jM5By9IlRuEnACJVUhRqlIx8uWFhCF42UnVkFEgWS9VgtzSPEKxuVZDyTDqREJMUqOQQe5LQBMVAhOFBlF8qoa6KqORIMcu0NDoAVq/iH49/ATSOpjSs+gowt5psMGrI2bswSgPqoKgJjRn7lLdX6Q7szCgW45xWi6hwSiiO/QVaKX5fzXsmtOFFDcOvfWLmV+0wTI+mZZFD5i7t2IuzLGrjWg3gb5drGXRA+gak3noGl3aAKBjvkVJgYEjzUl3t7LddMDG8CzoYryOVaYvh7NjvknR+skiTeIPVwNOOhZdnNDxyPDKWWNG9AXnxx5aHh1AFvmNnDkw8lIxPxgP1HOMFPyRGfObbuK/KKeBmao3tlDdtsGDeOYK1cLBbFl/gUPGNdFTGbF6XB4uQqrZG54OVa8MaANwyUlTDkPMC3Ozapfcjy2YWXa3kg0hkyDuYlIEhzkaBKtWcBuOmT9uk1dMamGt8oPY4lPh+uUH7BtL2hshkw/HakerKvRzYLGoAFOVR9p+cX89Qdz1lNwE6g2Sa/JeyB11rgzeta1KT8xZlMA2zoUWndSzex080Eg7mDWTQdaPSAW9fzsgUwal1Yh6Ds0MfQ6RGlUaitNeXPoqR5W/Qw2pkbWhICm5bF3Kx8giaqYhNbrosY3zc1FVxTmPR5eaI9+kfEBHaobSHg7d8nmvgbpAJ+iQSliFov8VQh5DfYJ9lYArz+CxLzfDFjIjLrtT9bB3N/WVJ2hmVtXRkY/Ac1da1qFvZiCDnIMpKT3M7Vx9g4y4LncwI2WEqWLTd10AJw+M82wwFMr7Tp7dHYZiF4iV9hXMHRZRni1wgNNRdujkahA4WEMsoLqAQtegNAyxLMEoUl2AoXFJh8GoJWz3JlFvaPTOMGw3Jzgij6v3Z8+ru42HCQ4SmqtS6yIROo6D0uyrUkHGpFmojVlGQeksq5JmxvRiqBveIylVetGYiP0EKfa3bnmUIiWVUH2AlDplbUruf4CUOrlvKoPMT0pTBjEVjOYnpSkYmUprs5PSltYMRcjZSVEjVT3wAfXl2tlJ6V+tL2zPTcpQ2Na3AMxNytACoG+WmJmUqVlCVDb6UzUzKWNbCfflrj3nYl5SvBdE4/ZqWpXmJWVpVdI1dc1KytrUpWl/m5MU78bXtr+5Ngp6AEm5oYAmeiQ9HUmxIaBZMDXjOzafTgY/N2ZMIoo23Q8cUAfbdN0bmqeAB7mWhuZFS8k6uPV7NODWb4m+Omr0B4cmeaFinU8lucHpOMF3HrxYBDxML7/miIpc3f/AYR64HCsemWcFxxx7+s4DYvJRutO3HKXrHDr0rUWlQ4dHR5HtHM/0KFhTjmfOd5B1KeZphLhGUs+BtyO/0hn3MUd+u4ejlz4OR68K6fKEcYej/R8jl9s9qvFymsiJ4WnnbEP5ZPuEA/eL3tUE1ylXE8illN3EWY87d118xyUOf5B0C8ffcN3FYnAxyDN1OIO5WJ17F6n4uRhkeIXKcpOCQhGkm96jiT9naHjZzBK5bKb/zDP1at1V1/Jcm/2jVb4lbB8fuJZn8ZUXGP0gGXn71BvzXPX0xjdeirX4yuvDfuB80dqH7vKLg71K6gfYfexKOoavu7yPELJrDi8ym2O5LxK1/vochhdC/i6ff/ht/AeTm1/dJrEzIwAAAABJRU5ErkJggg==',
                                                              ),
                                                              useHeroAnimation:
                                                                  true,
                                                            ),
                                                          ),
                                                        );
                                                      },
                                                      child: Hero(
                                                        tag: valueOrDefault<
                                                            String>(
                                                          currentUserPhoto,
                                                          'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJQAAACUCAMAAABC4vDmAAAAY1BMVEX///8AAADR0dHl5eX29vbi4uLw8PCqqqp0dHTt7e3a2tr8/Pw/Pz+UlJTz8/NlZWWEhIQxMTE6OjpcXFyOjo4ODg5GRkbFxcVUVFSwsLAcHBwhISFLS0u8vLyioqIXFxcpKSkQ0Ih2AAAHbElEQVR4nO1c2baiOhRUBhkUAVFx1v//ytuezk4CZKhA8LjW7XrrPhKKZGfPyWLxD/9nrFdhnOcBQ57H4Wr9q4TiNimq8lg/lxzP+lhWRdLGv0Joe05v9WWpwaW+peftRwnFQVXr6Mio98GHZiy6V0eE0V8cq3s0N6N1VtUHnNIbh7rK5hT9bVu6ESKU7WzylTTjKP3QSuZgFN13inc9680pLc5tHmZRlIV5ey7S00bWERw778K1bm+Dt7yafdJmql9nbbJvroMHbq1X2YrTvnQf0jZXEuLE8lbxkD8NET16Y2/SHHsyTzc9Yg9Pa9h25fuQ3h220vaedgWsaX1wenQHrXLHb43yqjPAdfo+jE/ygLti1OxHRWfnNhMlK5Bt3KsYPVpcyJuxDqZwSuSlK8MpQ4WyMbicR48TycLQTPq6NwJ5w1Qjd+EqlbZc4cF4bQuJVboaM0Qk6fDN5Gn6i2AjxjyNmKtMPH9I/VB6Q9LyG6NFUHISquDg08CvE8Hq5MgqEvP0BE0KilyaK6cVXIl5aiYpAhVCMfjJQdojse9K54W3IxMqK8WdmWrMQw5YC1YV+kwyWcXZIKllcBcF3Laks0VHEZ+rC6QCY26DyxkjI7GCNWLl+d5onGR8vd06fYNQhI39x9z1feK6IDtXadk0ZVqd8T0ecn1lFauWBOqA6sws6eQVNmd0grkWvVo85IjcC9S2ZI9BqmOXgNPFLU5j3lB88UAbHChzHTfMqVhzHf0w/Szmi4CNuldR+nkLJvTcwhp2IKd+gD51nWooLVFNHfCF0X9ES4tcQENWGkIOrMgXPWhlnfuaDeL7ro2cwA/b0sa66WT9TuNBi3c2czJ8vAy+gHfNDyhiLJHR1hZOf7QvMsyCpmqn/jM5By9IlRuEnACJVUhRqlIx8uWFhCF42UnVkFEgWS9VgtzSPEKxuVZDyTDqREJMUqOQQe5LQBMVAhOFBlF8qoa6KqORIMcu0NDoAVq/iH49/ATSOpjSs+gowt5psMGrI2bswSgPqoKgJjRn7lLdX6Q7szCgW45xWi6hwSiiO/QVaKX5fzXsmtOFFDcOvfWLmV+0wTI+mZZFD5i7t2IuzLGrjWg3gb5drGXRA+gak3noGl3aAKBjvkVJgYEjzUl3t7LddMDG8CzoYryOVaYvh7NjvknR+skiTeIPVwNOOhZdnNDxyPDKWWNG9AXnxx5aHh1AFvmNnDkw8lIxPxgP1HOMFPyRGfObbuK/KKeBmao3tlDdtsGDeOYK1cLBbFl/gUPGNdFTGbF6XB4uQqrZG54OVa8MaANwyUlTDkPMC3Ozapfcjy2YWXa3kg0hkyDuYlIEhzkaBKtWcBuOmT9uk1dMamGt8oPY4lPh+uUH7BtL2hshkw/HakerKvRzYLGoAFOVR9p+cX89Qdz1lNwE6g2Sa/JeyB11rgzeta1KT8xZlMA2zoUWndSzex080Eg7mDWTQdaPSAW9fzsgUwal1Yh6Ds0MfQ6RGlUaitNeXPoqR5W/Qw2pkbWhICm5bF3Kx8giaqYhNbrosY3zc1FVxTmPR5eaI9+kfEBHaobSHg7d8nmvgbpAJ+iQSliFov8VQh5DfYJ9lYArz+CxLzfDFjIjLrtT9bB3N/WVJ2hmVtXRkY/Ac1da1qFvZiCDnIMpKT3M7Vx9g4y4LncwI2WEqWLTd10AJw+M82wwFMr7Tp7dHYZiF4iV9hXMHRZRni1wgNNRdujkahA4WEMsoLqAQtegNAyxLMEoUl2AoXFJh8GoJWz3JlFvaPTOMGw3Jzgij6v3Z8+ru42HCQ4SmqtS6yIROo6D0uyrUkHGpFmojVlGQeksq5JmxvRiqBveIylVetGYiP0EKfa3bnmUIiWVUH2AlDplbUruf4CUOrlvKoPMT0pTBjEVjOYnpSkYmUprs5PSltYMRcjZSVEjVT3wAfXl2tlJ6V+tL2zPTcpQ2Na3AMxNytACoG+WmJmUqVlCVDb6UzUzKWNbCfflrj3nYl5SvBdE4/ZqWpXmJWVpVdI1dc1KytrUpWl/m5MU78bXtr+5Ngp6AEm5oYAmeiQ9HUmxIaBZMDXjOzafTgY/N2ZMIoo23Q8cUAfbdN0bmqeAB7mWhuZFS8k6uPV7NODWb4m+Omr0B4cmeaFinU8lucHpOMF3HrxYBDxML7/miIpc3f/AYR64HCsemWcFxxx7+s4DYvJRutO3HKXrHDr0rUWlQ4dHR5HtHM/0KFhTjmfOd5B1KeZphLhGUs+BtyO/0hn3MUd+u4ejlz4OR68K6fKEcYej/R8jl9s9qvFymsiJ4WnnbEP5ZPuEA/eL3tUE1ylXE8illN3EWY87d118xyUOf5B0C8ffcN3FYnAxyDN1OIO5WJ17F6n4uRhkeIXKcpOCQhGkm96jiT9naHjZzBK5bKb/zDP1at1V1/Jcm/2jVb4lbB8fuJZn8ZUXGP0gGXn71BvzXPX0xjdeirX4yuvDfuB80dqH7vKLg71K6gfYfexKOoavu7yPELJrDi8ym2O5LxK1/vochhdC/i6ff/ht/AeTm1/dJrEzIwAAAABJRU5ErkJggg==',
                                                        ),
                                                        transitionOnUserGestures:
                                                            true,
                                                        child: ClipRRect(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      50.0),
                                                          child:
                                                              CachedNetworkImage(
                                                            fadeInDuration:
                                                                Duration(
                                                                    milliseconds:
                                                                        500),
                                                            fadeOutDuration:
                                                                Duration(
                                                                    milliseconds:
                                                                        500),
                                                            imageUrl:
                                                                valueOrDefault<
                                                                    String>(
                                                              currentUserPhoto,
                                                              'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJQAAACUCAMAAABC4vDmAAAAY1BMVEX///8AAADR0dHl5eX29vbi4uLw8PCqqqp0dHTt7e3a2tr8/Pw/Pz+UlJTz8/NlZWWEhIQxMTE6OjpcXFyOjo4ODg5GRkbFxcVUVFSwsLAcHBwhISFLS0u8vLyioqIXFxcpKSkQ0Ih2AAAHbElEQVR4nO1c2baiOhRUBhkUAVFx1v//ytuezk4CZKhA8LjW7XrrPhKKZGfPyWLxD/9nrFdhnOcBQ57H4Wr9q4TiNimq8lg/lxzP+lhWRdLGv0Joe05v9WWpwaW+peftRwnFQVXr6Mio98GHZiy6V0eE0V8cq3s0N6N1VtUHnNIbh7rK5hT9bVu6ESKU7WzylTTjKP3QSuZgFN13inc9680pLc5tHmZRlIV5ey7S00bWERw778K1bm+Dt7yafdJmql9nbbJvroMHbq1X2YrTvnQf0jZXEuLE8lbxkD8NET16Y2/SHHsyTzc9Yg9Pa9h25fuQ3h220vaedgWsaX1wenQHrXLHb43yqjPAdfo+jE/ygLti1OxHRWfnNhMlK5Bt3KsYPVpcyJuxDqZwSuSlK8MpQ4WyMbicR48TycLQTPq6NwJ5w1Qjd+EqlbZc4cF4bQuJVboaM0Qk6fDN5Gn6i2AjxjyNmKtMPH9I/VB6Q9LyG6NFUHISquDg08CvE8Hq5MgqEvP0BE0KilyaK6cVXIl5aiYpAhVCMfjJQdojse9K54W3IxMqK8WdmWrMQw5YC1YV+kwyWcXZIKllcBcF3Laks0VHEZ+rC6QCY26DyxkjI7GCNWLl+d5onGR8vd06fYNQhI39x9z1feK6IDtXadk0ZVqd8T0ecn1lFauWBOqA6sws6eQVNmd0grkWvVo85IjcC9S2ZI9BqmOXgNPFLU5j3lB88UAbHChzHTfMqVhzHf0w/Szmi4CNuldR+nkLJvTcwhp2IKd+gD51nWooLVFNHfCF0X9ES4tcQENWGkIOrMgXPWhlnfuaDeL7ro2cwA/b0sa66WT9TuNBi3c2czJ8vAy+gHfNDyhiLJHR1hZOf7QvMsyCpmqn/jM5By9IlRuEnACJVUhRqlIx8uWFhCF42UnVkFEgWS9VgtzSPEKxuVZDyTDqREJMUqOQQe5LQBMVAhOFBlF8qoa6KqORIMcu0NDoAVq/iH49/ATSOpjSs+gowt5psMGrI2bswSgPqoKgJjRn7lLdX6Q7szCgW45xWi6hwSiiO/QVaKX5fzXsmtOFFDcOvfWLmV+0wTI+mZZFD5i7t2IuzLGrjWg3gb5drGXRA+gak3noGl3aAKBjvkVJgYEjzUl3t7LddMDG8CzoYryOVaYvh7NjvknR+skiTeIPVwNOOhZdnNDxyPDKWWNG9AXnxx5aHh1AFvmNnDkw8lIxPxgP1HOMFPyRGfObbuK/KKeBmao3tlDdtsGDeOYK1cLBbFl/gUPGNdFTGbF6XB4uQqrZG54OVa8MaANwyUlTDkPMC3Ozapfcjy2YWXa3kg0hkyDuYlIEhzkaBKtWcBuOmT9uk1dMamGt8oPY4lPh+uUH7BtL2hshkw/HakerKvRzYLGoAFOVR9p+cX89Qdz1lNwE6g2Sa/JeyB11rgzeta1KT8xZlMA2zoUWndSzex080Eg7mDWTQdaPSAW9fzsgUwal1Yh6Ds0MfQ6RGlUaitNeXPoqR5W/Qw2pkbWhICm5bF3Kx8giaqYhNbrosY3zc1FVxTmPR5eaI9+kfEBHaobSHg7d8nmvgbpAJ+iQSliFov8VQh5DfYJ9lYArz+CxLzfDFjIjLrtT9bB3N/WVJ2hmVtXRkY/Ac1da1qFvZiCDnIMpKT3M7Vx9g4y4LncwI2WEqWLTd10AJw+M82wwFMr7Tp7dHYZiF4iV9hXMHRZRni1wgNNRdujkahA4WEMsoLqAQtegNAyxLMEoUl2AoXFJh8GoJWz3JlFvaPTOMGw3Jzgij6v3Z8+ru42HCQ4SmqtS6yIROo6D0uyrUkHGpFmojVlGQeksq5JmxvRiqBveIylVetGYiP0EKfa3bnmUIiWVUH2AlDplbUruf4CUOrlvKoPMT0pTBjEVjOYnpSkYmUprs5PSltYMRcjZSVEjVT3wAfXl2tlJ6V+tL2zPTcpQ2Na3AMxNytACoG+WmJmUqVlCVDb6UzUzKWNbCfflrj3nYl5SvBdE4/ZqWpXmJWVpVdI1dc1KytrUpWl/m5MU78bXtr+5Ngp6AEm5oYAmeiQ9HUmxIaBZMDXjOzafTgY/N2ZMIoo23Q8cUAfbdN0bmqeAB7mWhuZFS8k6uPV7NODWb4m+Omr0B4cmeaFinU8lucHpOMF3HrxYBDxML7/miIpc3f/AYR64HCsemWcFxxx7+s4DYvJRutO3HKXrHDr0rUWlQ4dHR5HtHM/0KFhTjmfOd5B1KeZphLhGUs+BtyO/0hn3MUd+u4ejlz4OR68K6fKEcYej/R8jl9s9qvFymsiJ4WnnbEP5ZPuEA/eL3tUE1ylXE8illN3EWY87d118xyUOf5B0C8ffcN3FYnAxyDN1OIO5WJ17F6n4uRhkeIXKcpOCQhGkm96jiT9naHjZzBK5bKb/zDP1at1V1/Jcm/2jVb4lbB8fuJZn8ZUXGP0gGXn71BvzXPX0xjdeirX4yuvDfuB80dqH7vKLg71K6gfYfexKOoavu7yPELJrDi8ym2O5LxK1/vochhdC/i6ff/ht/AeTm1/dJrEzIwAAAABJRU5ErkJggg==',
                                                            ),
                                                            width: 100.0,
                                                            height: 100.0,
                                                            fit: BoxFit.cover,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 12.0, 0.0, 4.0),
                                      child: AuthUserStreamWidget(
                                        builder: (context) => Text(
                                          valueOrDefault<String>(
                                            currentUserDisplayName,
                                            'John Doe',
                                          ),
                                          textAlign: TextAlign.center,
                                          style: FlutterFlowTheme.of(context)
                                              .headlineSmall
                                              .override(
                                                font: GoogleFonts.interTight(
                                                  fontWeight:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .headlineSmall
                                                          .fontWeight,
                                                  fontStyle:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .headlineSmall
                                                          .fontStyle,
                                                ),
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryText,
                                                letterSpacing: 0.0,
                                                fontWeight:
                                                    FlutterFlowTheme.of(context)
                                                        .headlineSmall
                                                        .fontWeight,
                                                fontStyle:
                                                    FlutterFlowTheme.of(context)
                                                        .headlineSmall
                                                        .fontStyle,
                                              ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ].divide(SizedBox(height: 8.0)),
                          ),
                        ),
                        FFButtonWidget(
                          onPressed: () async {
                            context.pushNamed(MyProfileWidget.routeName);
                          },
                          text: 'My Profile',
                          options: FFButtonOptions(
                            height: 40.0,
                            padding: EdgeInsetsDirectional.fromSTEB(
                                16.0, 0.0, 16.0, 0.0),
                            iconPadding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 0.0),
                            color: FlutterFlowTheme.of(context).primary,
                            textStyle: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  font: GoogleFonts.inter(
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .fontStyle,
                                  ),
                                  color: Colors.white,
                                  letterSpacing: 0.0,
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .fontStyle,
                                ),
                            elevation: 0.0,
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: MediaQuery.sizeOf(context).width * 0.95,
                    decoration: BoxDecoration(
                      color: Colors.black,
                    ),
                    child: Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(
                          20.0, 20.0, 20.0, 20.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            'My Rides',
                            style: FlutterFlowTheme.of(context)
                                .titleMedium
                                .override(
                                  font: GoogleFonts.interTight(
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .titleMedium
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .titleMedium
                                        .fontStyle,
                                  ),
                                  color: Colors.white,
                                  letterSpacing: 0.0,
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .titleMedium
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .titleMedium
                                      .fontStyle,
                                ),
                          ),
                          StreamBuilder<List<RidesRecord>>(
                            stream: queryRidesRecord(
                              parent: currentUserReference,
                              queryBuilder: (ridesRecord) =>
                                  ridesRecord.orderBy('created_at'),
                            ),
                            builder: (context, snapshot) {
                              // Customize what your widget looks like when it's loading.
                              if (!snapshot.hasData) {
                                return Center(
                                  child: SizedBox(
                                    width: 50.0,
                                    height: 50.0,
                                    child: CircularProgressIndicator(
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                        FlutterFlowTheme.of(context).primary,
                                      ),
                                    ),
                                  ),
                                );
                              }
                              List<RidesRecord> listViewRidesRecordList =
                                  snapshot.data!;
                              if (listViewRidesRecordList.isEmpty) {
                                return Image.network(
                                  'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMIAAAEDCAMAAABQ/CumAAAAgVBMVEUAAAD////d3d3Dw8Onp6cODg5cXFxpaWlRUVHOzs6jo6PIyMi9vb36+vooKChXV1fy8vI7Ozt4eHi4uLhwcHCEhISenp5HR0e0tLSSkpJBQUFkZGStrq3k5ORMTEyRkZEyMjIbGxsiIiLr6+vX19eIiIgkJCR9fX0TExMuLi4bHBtvMEk+AAAJeElEQVR4nO2c62KiOBSAE0ARBQVBlJtixarz/g+4uZIEtWVLsZ3d8/3oUAqYjySQcxIHIQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOC/SLROimIlflmt3SS5il+Wh/l8nu7bA4uiSNYJOZock7hFMaV7Z2uX7p7Q7S3fXiI0oRctEnrZKT00Etdw1+66kBecbMj1s+l02n7EF6ndFGMsPmNf2Ik74ds+vhyJVGWJTyjJYRu3yDC2pq7bkN/YGdMK44yfExUexk7xRkrnHjA+FfTMWbHAuBIfNi0abk7IgsORuAbkegMVECpIaWz5iyP+vZ7wlm+dsCuUTkd+tMeNgiPbT4otS0WOwRe+tVIlo+5Je4TcsMVZf0J8Gqywtsln1FJB1EHTWiUYL/ke5uQKBWQJx+YzhbRR1YDkVVNciq0Ch4MVLkmoqkEouNqNC3BM/znZ8i9cYYp5qya10DZvorC5U5hPyS1yTYUc4zd5UhO8D1YoaG/IDQVSrraThbzVi4K2Cihcy0P1WrhXcFClqkEo2LhpP38tm+wAhYTcaFkNQiFsezhtMfQevonqVgp+1lchUb2Bf8wfUbMcdf4ABaetBq5QY1OBFDavugqHuK8CrQZLVyDPBNkV6Aesv0HhSorsawrbjkJKiu51FcSePgqXthq4wsFQiNNvUGDVUD9XmCN023YV3ma9FVRv4ApzQyH6jr6AjvLd8FRBohQEvRQ25ILrZwrDoQooFoUeSYE+H6qRFW44YNXwJQU5xKI34onCWfQGruCMocCqYfsVBfLuXcR+TPDj6qmCrIYxFSL+UPqSQo9aQBmvhjEVaDvG9Wh9QVbDXV9Y76ymKeUAf5hCxB5KX1L4eIwkFFL2ULrvzlttEDhQAZFxPb6NVwuTgJZ1XIU97Q3paAq03LjgY4B0JAVamIDfpfx+gDFcAZGLVlzhMpbCDItoEi07CuePFXr1BR6+tbdoN4oCkgExjTZlAMHGN1qAPqAW3lWEW6mLfK/CqlXYaQ/7wIgMByjQqy74VoIDufN7FWib4RtL1Xhqox0NUri1CiRsk/3rmxUKqUBG9DKv4JhFfvR2/jj8Vwrk7d2mSjwZThOFwSkMTYG0Ubm1ETfsooeISCVhWj5NwmgKy7YW6IijZA9wBwcDo7ap7fv2rC1ge5fQNfXSLLNjI9d29GOfoKQ3ZIBHLsAGCAkb7NnkOXC16cDPpw0wI4fHE3l4mmkXOy/KNCstfdf3cxz16oTr2+fHAAAAAAAAAP9TlnmU72ezfZ5v6c8ob+N+VKSOc36UaFtl83lS1zX922TFT6WQrZxOj77PtpHaF+UDk3WfQfPB8+xAopXqnGWnNnxGKXbeSRAQenXnjHmT7Y8FTWDS4PGaxfxUAk0V0QgpP5BAyDvQXQcSMBuR6wgscEjLmIjsgicDc0/O8IV4ph9/PYnJygvGPCArVEhch2Iqc66ST1N53GhUPMWylgmSkM+U+218ucbBxDh+KbZKkQxylQKJhHksrymgs0oajUNoi4JiuUHTLzNV+0djhjXTlkyIO64rIJtnbBw9BXhSfx6FgOfiWgUU0NRCrCWSKrncgv+iyhPz1IOhUPB2qNcCOgxfovARkbi8UvBoEiLEak7e0lKOk1CrBZcX11BAAXuiGQr5uAp7USKlMKcpBWwqtMVZBrjtC+gtZLVjKjSs8xsK6DTqUzURBVcKa5vPl+gKqj+GcpKd/cISr6aCx1JcpkI1eGb5I3LRRpRC5PLsvK6g+jN54Mt0F3mu3uhPqTBlua2CaUmFC/uZ3MZUkKy1dVUdhUZXoEtCcGKcKhUyrB6+UsEO0Mvoq0BehUGAF0vtVKlweKDgj9uTDXor0PkGjAMtjSgVzg8U4l+pwOYVMbbaZCtRqOaOM/c0BfJqa8i+tPqdCsgNmYQc+TxqSM6vbkiUkjmIKb+/UwHtWY/gEwsfdedf2hc49AVhDvMOWL2E24fq71O4qikeEh0FDwYY5YO38yJHL8BUiDoK2gCjndRYyWM6AwzWujoDjPr7C3yPqYA6CuotELaDVjrwYA9WU+HE9pkKr2lNHYWTqaBWklpqIdFOLEk0FG587a+hUPyIwk4rdoVD9ajx1aCnFEGmoXB4EPL4w9fG96GjQDrDQWy+B3r4XqoxnieGrIZCeB94Ho0rj0dHQYuRz8bsfNouZ8jlc0pXKMVpei0037uK7SldBVJW/hia4uaPtntDBkQstFyF3QEG0lZZKIU3z1jPNBq32Pe8RVzo+/J4MT9nvmfOzc+spjnZc8ffie5+9empO4bfeB5tf/vY9jyb7yNbjYt+jMnt8dT2EWa8AQAAAAAAgLF5y+vlss5ZSHDNI7pNg98oui1vESUnW0uWyN7mdR1tCZG2+PNG/8yOy6NaHPhi9imd5ebfj69TG2Mro/OEhzTAYUrJUvmdtLTE+JSRHbswsGVkndDZ9jJjR1o4wM8+Z1T0GPHSTkMd1YL5ayWm09UqZj0Ss9SXA2w8/Iu/X8HRirNpFZaByltMAsyazlQtxD6pWVCi0C4PsPCPBGifK6AD/06JppCqeFlX2Kt5uFfSQ+HIb7mmsFJL9nUFVI27iPwJPRRQw3IAmsIVt13FUHAe5MDHp4+Cw26upjB5ouCaX254EX0ULuzm9lCoB3+p5St8rHDM6NzAlvVSTeF23xcOtL9cf2FfiLBKhWkKidqUCo+mgl7EZwpqql9T2KmTWoWRF059gPPw7bwUb+f6ocKW/FUOlOTb+QcV5nyWmzJf6ArBgZCaDanaT1ezpMSB3eYkiYJDDhx9+doHEAXneGO8nY1aoCs+p6bC6bJJ4wBbWgKZ/m8lZJx6+9mG9KQv0H8fNiRHz+T/jr7wr59IpTaP+5cq6P/vza9/qE72tN8W7AhNoVRzcVJhWyP6vcLXFNqkzwBjwxqJprBWC2GMAUb+msnNDn0UdmzdrTnYlnOAhsJ65FW1j+mjUHUH29snCvFrJjc79FCo70KeZwrhAf0APRR2d4HnE4XktwaeK7F2XlN4p915y8Q0hWOIjXnfVzE3FcRTUUvCTIO7JAx9MfjozIZ3Kglzq34kCTNzbMuyHXYfozK2rIVDs1yZY1kNH/uVlmWxcNLZWY3niCwLkS2p7drxLKvkR5IDf+SZ+lWu7uD/Kw4AAAAAAAAAAAAAAAAAgC7/ADSUlF7QO2uKAAAAAElFTkSuQmCC',
                                );
                              }

                              return ListView.builder(
                                padding: EdgeInsets.zero,
                                primary: false,
                                shrinkWrap: true,
                                scrollDirection: Axis.vertical,
                                itemCount: listViewRidesRecordList.length,
                                itemBuilder: (context, listViewIndex) {
                                  final listViewRidesRecord =
                                      listViewRidesRecordList[listViewIndex];
                                  return Column(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Row(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                        children: [
                                          Align(
                                            alignment:
                                                AlignmentDirectional(-1.0, 0.0),
                                            child: Text(
                                              valueOrDefault<String>(
                                                listViewRidesRecord.rideName,
                                                'Ride name',
                                              ),
                                              style: FlutterFlowTheme.of(
                                                      context)
                                                  .bodyMedium
                                                  .override(
                                                    font: GoogleFonts.inter(
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontStyle:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .bodyMedium
                                                              .fontStyle,
                                                    ),
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .primary,
                                                    letterSpacing: 0.0,
                                                    fontWeight: FontWeight.bold,
                                                    fontStyle:
                                                        FlutterFlowTheme.of(
                                                                context)
                                                            .bodyMedium
                                                            .fontStyle,
                                                  ),
                                            ),
                                          ),
                                          Align(
                                            alignment:
                                                AlignmentDirectional(-1.0, 0.0),
                                            child: Text(
                                              valueOrDefault<String>(
                                                listViewRidesRecord.model,
                                                '2000',
                                              ),
                                              style: FlutterFlowTheme.of(
                                                      context)
                                                  .bodyMedium
                                                  .override(
                                                    font: GoogleFonts.inter(
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      fontStyle:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .bodyMedium
                                                              .fontStyle,
                                                    ),
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .primary,
                                                    letterSpacing: 0.0,
                                                    fontWeight: FontWeight.w500,
                                                    fontStyle:
                                                        FlutterFlowTheme.of(
                                                                context)
                                                            .bodyMedium
                                                            .fontStyle,
                                                  ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      ClipRRect(
                                        borderRadius:
                                            BorderRadius.circular(8.0),
                                        child: CachedNetworkImage(
                                          fadeInDuration:
                                              Duration(milliseconds: 500),
                                          fadeOutDuration:
                                              Duration(milliseconds: 500),
                                          imageUrl: valueOrDefault<String>(
                                            listViewRidesRecord.imageUrl,
                                            'https://avatars.mds.yandex.net/i?id=4ad232f739be91ec01a93860a855473d1301814a-5235444-images-thumbs&n=13',
                                          ),
                                          width:
                                              MediaQuery.sizeOf(context).width *
                                                  0.95,
                                          height: 200.0,
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ],
                                  );
                                },
                              );
                            },
                          ),
                        ].divide(SizedBox(height: 16.0)),
                      ),
                    ),
                  ),
                  Container(
                    width: MediaQuery.sizeOf(context).width * 0.95,
                    decoration: BoxDecoration(
                      color: Color(0xFF0F0E0E),
                    ),
                    child: Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(
                          20.0, 20.0, 20.0, 20.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Add Your Rides',
                                style: FlutterFlowTheme.of(context)
                                    .titleMedium
                                    .override(
                                      font: GoogleFonts.interTight(
                                        fontWeight: FlutterFlowTheme.of(context)
                                            .titleMedium
                                            .fontWeight,
                                        fontStyle: FlutterFlowTheme.of(context)
                                            .titleMedium
                                            .fontStyle,
                                      ),
                                      color: Colors.white,
                                      letterSpacing: 0.0,
                                      fontWeight: FlutterFlowTheme.of(context)
                                          .titleMedium
                                          .fontWeight,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .titleMedium
                                          .fontStyle,
                                    ),
                              ),
                            ],
                          ),
                          Column(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 5.0, 0.0, 5.0),
                                child: FFButtonWidget(
                                  onPressed: () async {
                                    context.pushNamed(RideWidget.routeName);
                                  },
                                  text: 'Add Ride',
                                  icon: Icon(
                                    Icons.forward_rounded,
                                    size: 15.0,
                                  ),
                                  options: FFButtonOptions(
                                    width: 300.0,
                                    height: 50.0,
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        16.0, 0.0, 16.0, 0.0),
                                    iconAlignment: IconAlignment.end,
                                    iconPadding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 0.0, 0.0, 0.0),
                                    color: FlutterFlowTheme.of(context).primary,
                                    textStyle: FlutterFlowTheme.of(context)
                                        .titleSmall
                                        .override(
                                          font: GoogleFonts.interTight(
                                            fontWeight:
                                                FlutterFlowTheme.of(context)
                                                    .titleSmall
                                                    .fontWeight,
                                            fontStyle:
                                                FlutterFlowTheme.of(context)
                                                    .titleSmall
                                                    .fontStyle,
                                          ),
                                          color: Colors.white,
                                          letterSpacing: 0.0,
                                          fontWeight:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .fontWeight,
                                          fontStyle:
                                              FlutterFlowTheme.of(context)
                                                  .titleSmall
                                                  .fontStyle,
                                        ),
                                    elevation: 0.0,
                                    borderRadius: BorderRadius.circular(20.0),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ].divide(SizedBox(height: 16.0)),
                      ),
                    ),
                  ),
                  Container(
                    width: MediaQuery.sizeOf(context).width * 0.95,
                    decoration: BoxDecoration(
                      color: Color(0xFF0F0E0E),
                    ),
                  ),
                ].divide(SizedBox(height: 24.0)),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
