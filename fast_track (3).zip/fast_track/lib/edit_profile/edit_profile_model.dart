import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_expanded_image_view.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:async';
import 'dart:ui';
import '/index.dart';
import 'edit_profile_widget.dart' show EditProfileWidget;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';

class EditProfileModel extends FlutterFlowModel<EditProfileWidget> {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode1;
  TextEditingController? textController1;
  String? Function(BuildContext, String?)? textController1Validator;
  String? _textController1Validator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Full Name is required';
    }

    return null;
  }

  // State field(s) for DropDown widget.
  String? dropDownValue;
  FormFieldController<String>? dropDownValueController;
  // State field(s) for DropDownSex widget.
  String? dropDownSexValue;
  FormFieldController<String>? dropDownSexValueController;
  // State field(s) for DropDownRelationshipStatus widget.
  String? dropDownRelationshipStatusValue;
  FormFieldController<String>? dropDownRelationshipStatusValueController;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode2;
  TextEditingController? textController2;
  String? Function(BuildContext, String?)? textController2Validator;
  String? _textController2Validator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Age is required';
    }

    return null;
  }

  // State field(s) for TextFieldEthnicity widget.
  FocusNode? textFieldEthnicityFocusNode;
  TextEditingController? textFieldEthnicityTextController;
  String? Function(BuildContext, String?)?
      textFieldEthnicityTextControllerValidator;
  String? _textFieldEthnicityTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Ethnicity is required';
    }

    return null;
  }

  // State field(s) for TextFieldReligion widget.
  FocusNode? textFieldReligionFocusNode;
  TextEditingController? textFieldReligionTextController;
  String? Function(BuildContext, String?)?
      textFieldReligionTextControllerValidator;
  String? _textFieldReligionTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Religion is required';
    }

    return null;
  }

  // State field(s) for TextFieldDOB widget.
  FocusNode? textFieldDOBFocusNode;
  TextEditingController? textFieldDOBTextController;
  late MaskTextInputFormatter textFieldDOBMask;
  String? Function(BuildContext, String?)? textFieldDOBTextControllerValidator;
  String? _textFieldDOBTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'DOB is required';
    }

    return null;
  }

  // State field(s) for TextFieldEmail widget.
  FocusNode? textFieldEmailFocusNode;
  TextEditingController? textFieldEmailTextController;
  String? Function(BuildContext, String?)?
      textFieldEmailTextControllerValidator;
  String? _textFieldEmailTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Email is required';
    }

    return null;
  }

  // State field(s) for TextFieldCity widget.
  FocusNode? textFieldCityFocusNode;
  TextEditingController? textFieldCityTextController;
  String? Function(BuildContext, String?)? textFieldCityTextControllerValidator;
  String? _textFieldCityTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'City your were born is required';
    }

    return null;
  }

  // State field(s) for TextFieldHobbies widget.
  FocusNode? textFieldHobbiesFocusNode;
  TextEditingController? textFieldHobbiesTextController;
  String? Function(BuildContext, String?)?
      textFieldHobbiesTextControllerValidator;
  String? _textFieldHobbiesTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Hobbies is required';
    }

    return null;
  }

  // State field(s) for TextFieldDreamRide widget.
  FocusNode? textFieldDreamRideFocusNode;
  TextEditingController? textFieldDreamRideTextController;
  String? Function(BuildContext, String?)?
      textFieldDreamRideTextControllerValidator;
  String? _textFieldDreamRideTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Dream Ride is required';
    }

    return null;
  }

  // State field(s) for TextFieldFavTrack widget.
  FocusNode? textFieldFavTrackFocusNode;
  TextEditingController? textFieldFavTrackTextController;
  String? Function(BuildContext, String?)?
      textFieldFavTrackTextControllerValidator;
  // State field(s) for TextFieldFutureMods widget.
  FocusNode? textFieldFutureModsFocusNode;
  TextEditingController? textFieldFutureModsTextController;
  String? Function(BuildContext, String?)?
      textFieldFutureModsTextControllerValidator;
  bool isDataUploading_uploadDataUserphotoUrl = false;
  FFUploadedFile uploadedLocalFile_uploadDataUserphotoUrl =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl_uploadDataUserphotoUrl = '';

  @override
  void initState(BuildContext context) {
    textController1Validator = _textController1Validator;
    textController2Validator = _textController2Validator;
    textFieldEthnicityTextControllerValidator =
        _textFieldEthnicityTextControllerValidator;
    textFieldReligionTextControllerValidator =
        _textFieldReligionTextControllerValidator;
    textFieldDOBTextControllerValidator = _textFieldDOBTextControllerValidator;
    textFieldEmailTextControllerValidator =
        _textFieldEmailTextControllerValidator;
    textFieldCityTextControllerValidator =
        _textFieldCityTextControllerValidator;
    textFieldHobbiesTextControllerValidator =
        _textFieldHobbiesTextControllerValidator;
    textFieldDreamRideTextControllerValidator =
        _textFieldDreamRideTextControllerValidator;
  }

  @override
  void dispose() {
    textFieldFocusNode1?.dispose();
    textController1?.dispose();

    textFieldFocusNode2?.dispose();
    textController2?.dispose();

    textFieldEthnicityFocusNode?.dispose();
    textFieldEthnicityTextController?.dispose();

    textFieldReligionFocusNode?.dispose();
    textFieldReligionTextController?.dispose();

    textFieldDOBFocusNode?.dispose();
    textFieldDOBTextController?.dispose();

    textFieldEmailFocusNode?.dispose();
    textFieldEmailTextController?.dispose();

    textFieldCityFocusNode?.dispose();
    textFieldCityTextController?.dispose();

    textFieldHobbiesFocusNode?.dispose();
    textFieldHobbiesTextController?.dispose();

    textFieldDreamRideFocusNode?.dispose();
    textFieldDreamRideTextController?.dispose();

    textFieldFavTrackFocusNode?.dispose();
    textFieldFavTrackTextController?.dispose();

    textFieldFutureModsFocusNode?.dispose();
    textFieldFutureModsTextController?.dispose();
  }
}
