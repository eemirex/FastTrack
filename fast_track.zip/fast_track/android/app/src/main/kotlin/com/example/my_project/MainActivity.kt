package com.mycompany.fasttrack

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
