import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class VictoriesRecord extends FirestoreRecord {
  VictoriesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "distance" field.
  String? _distance;
  String get distance => _distance ?? '';
  bool hasDistance() => _distance != null;

  // "location" field.
  String? _location;
  String get location => _location ?? '';
  bool hasLocation() => _location != null;

  // "raceName" field.
  String? _raceName;
  String get raceName => _raceName ?? '';
  bool hasRaceName() => _raceName != null;

  // "position" field.
  String? _position;
  String get position => _position ?? '';
  bool hasPosition() => _position != null;

  // "notes" field.
  String? _notes;
  String get notes => _notes ?? '';
  bool hasNotes() => _notes != null;

  // "posted_by" field.
  String? _postedBy;
  String get postedBy => _postedBy ?? '';
  bool hasPostedBy() => _postedBy != null;

  // "time_stamp" field.
  DateTime? _timeStamp;
  DateTime? get timeStamp => _timeStamp;
  bool hasTimeStamp() => _timeStamp != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "media" field.
  String? _media;
  String get media => _media ?? '';
  bool hasMedia() => _media != null;

  // "likes" field.
  List<DocumentReference>? _likes;
  List<DocumentReference> get likes => _likes ?? const [];
  bool hasLikes() => _likes != null;

  // "numVictoryComments" field.
  int? _numVictoryComments;
  int get numVictoryComments => _numVictoryComments ?? 0;
  bool hasNumVictoryComments() => _numVictoryComments != null;

  // "victoryUser" field.
  DocumentReference? _victoryUser;
  DocumentReference? get victoryUser => _victoryUser;
  bool hasVictoryUser() => _victoryUser != null;

  // "comments" field.
  List<String>? _comments;
  List<String> get comments => _comments ?? const [];
  bool hasComments() => _comments != null;

  void _initializeFields() {
    _distance = snapshotData['distance'] as String?;
    _location = snapshotData['location'] as String?;
    _raceName = snapshotData['raceName'] as String?;
    _position = snapshotData['position'] as String?;
    _notes = snapshotData['notes'] as String?;
    _postedBy = snapshotData['posted_by'] as String?;
    _timeStamp = snapshotData['time_stamp'] as DateTime?;
    _description = snapshotData['description'] as String?;
    _media = snapshotData['media'] as String?;
    _likes = getDataList(snapshotData['likes']);
    _numVictoryComments = castToType<int>(snapshotData['numVictoryComments']);
    _victoryUser = snapshotData['victoryUser'] as DocumentReference?;
    _comments = getDataList(snapshotData['comments']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('victories');

  static Stream<VictoriesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => VictoriesRecord.fromSnapshot(s));

  static Future<VictoriesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => VictoriesRecord.fromSnapshot(s));

  static VictoriesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      VictoriesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static VictoriesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      VictoriesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'VictoriesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is VictoriesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createVictoriesRecordData({
  String? distance,
  String? location,
  String? raceName,
  String? position,
  String? notes,
  String? postedBy,
  DateTime? timeStamp,
  String? description,
  String? media,
  int? numVictoryComments,
  DocumentReference? victoryUser,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'distance': distance,
      'location': location,
      'raceName': raceName,
      'position': position,
      'notes': notes,
      'posted_by': postedBy,
      'time_stamp': timeStamp,
      'description': description,
      'media': media,
      'numVictoryComments': numVictoryComments,
      'victoryUser': victoryUser,
    }.withoutNulls,
  );

  return firestoreData;
}

class VictoriesRecordDocumentEquality implements Equality<VictoriesRecord> {
  const VictoriesRecordDocumentEquality();

  @override
  bool equals(VictoriesRecord? e1, VictoriesRecord? e2) {
    const listEquality = ListEquality();
    return e1?.distance == e2?.distance &&
        e1?.location == e2?.location &&
        e1?.raceName == e2?.raceName &&
        e1?.position == e2?.position &&
        e1?.notes == e2?.notes &&
        e1?.postedBy == e2?.postedBy &&
        e1?.timeStamp == e2?.timeStamp &&
        e1?.description == e2?.description &&
        e1?.media == e2?.media &&
        listEquality.equals(e1?.likes, e2?.likes) &&
        e1?.numVictoryComments == e2?.numVictoryComments &&
        e1?.victoryUser == e2?.victoryUser &&
        listEquality.equals(e1?.comments, e2?.comments);
  }

  @override
  int hash(VictoriesRecord? e) => const ListEquality().hash([
        e?.distance,
        e?.location,
        e?.raceName,
        e?.position,
        e?.notes,
        e?.postedBy,
        e?.timeStamp,
        e?.description,
        e?.media,
        e?.likes,
        e?.numVictoryComments,
        e?.victoryUser,
        e?.comments
      ]);

  @override
  bool isValidKey(Object? o) => o is VictoriesRecord;
}
