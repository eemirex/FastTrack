import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UserRecord extends FirestoreRecord {
  UserRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "Rides" field.
  List<String>? _rides;
  List<String> get rides => _rides ?? const [];
  bool hasRides() => _rides != null;

  // "Race" field.
  String? _race;
  String get race => _race ?? '';
  bool hasRace() => _race != null;

  // "Sex" field.
  double? _sex;
  double get sex => _sex ?? 0.0;
  bool hasSex() => _sex != null;

  // "Relationshipstatus" field.
  String? _relationshipstatus;
  String get relationshipstatus => _relationshipstatus ?? '';
  bool hasRelationshipstatus() => _relationshipstatus != null;

  // "Age" field.
  int? _age;
  int get age => _age ?? 0;
  bool hasAge() => _age != null;

  // "Religion" field.
  String? _religion;
  String get religion => _religion ?? '';
  bool hasReligion() => _religion != null;

  // "DOB" field.
  DateTime? _dob;
  DateTime? get dob => _dob;
  bool hasDob() => _dob != null;

  // "City" field.
  String? _city;
  String get city => _city ?? '';
  bool hasCity() => _city != null;

  // "Hobbies" field.
  List<String>? _hobbies;
  List<String> get hobbies => _hobbies ?? const [];
  bool hasHobbies() => _hobbies != null;

  // "DreamRide" field.
  String? _dreamRide;
  String get dreamRide => _dreamRide ?? '';
  bool hasDreamRide() => _dreamRide != null;

  // "FavouriteTracks" field.
  List<String>? _favouriteTracks;
  List<String> get favouriteTracks => _favouriteTracks ?? const [];
  bool hasFavouriteTracks() => _favouriteTracks != null;

  // "FutureMods" field.
  List<String>? _futureMods;
  List<String> get futureMods => _futureMods ?? const [];
  bool hasFutureMods() => _futureMods != null;

  // "Followers" field.
  List<String>? _followers;
  List<String> get followers => _followers ?? const [];
  bool hasFollowers() => _followers != null;

  // "Following" field.
  List<String>? _following;
  List<String> get following => _following ?? const [];
  bool hasFollowing() => _following != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _rides = getDataList(snapshotData['Rides']);
    _race = snapshotData['Race'] as String?;
    _sex = castToType<double>(snapshotData['Sex']);
    _relationshipstatus = snapshotData['Relationshipstatus'] as String?;
    _age = castToType<int>(snapshotData['Age']);
    _religion = snapshotData['Religion'] as String?;
    _dob = snapshotData['DOB'] as DateTime?;
    _city = snapshotData['City'] as String?;
    _hobbies = getDataList(snapshotData['Hobbies']);
    _dreamRide = snapshotData['DreamRide'] as String?;
    _favouriteTracks = getDataList(snapshotData['FavouriteTracks']);
    _futureMods = getDataList(snapshotData['FutureMods']);
    _followers = getDataList(snapshotData['Followers']);
    _following = getDataList(snapshotData['Following']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('user');

  static Stream<UserRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UserRecord.fromSnapshot(s));

  static Future<UserRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UserRecord.fromSnapshot(s));

  static UserRecord fromSnapshot(DocumentSnapshot snapshot) => UserRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UserRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UserRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UserRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UserRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUserRecordData({
  String? email,
  String? displayName,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  String? race,
  double? sex,
  String? relationshipstatus,
  int? age,
  String? religion,
  DateTime? dob,
  String? city,
  String? dreamRide,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'Race': race,
      'Sex': sex,
      'Relationshipstatus': relationshipstatus,
      'Age': age,
      'Religion': religion,
      'DOB': dob,
      'City': city,
      'DreamRide': dreamRide,
    }.withoutNulls,
  );

  return firestoreData;
}

class UserRecordDocumentEquality implements Equality<UserRecord> {
  const UserRecordDocumentEquality();

  @override
  bool equals(UserRecord? e1, UserRecord? e2) {
    const listEquality = ListEquality();
    return e1?.email == e2?.email &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        listEquality.equals(e1?.rides, e2?.rides) &&
        e1?.race == e2?.race &&
        e1?.sex == e2?.sex &&
        e1?.relationshipstatus == e2?.relationshipstatus &&
        e1?.age == e2?.age &&
        e1?.religion == e2?.religion &&
        e1?.dob == e2?.dob &&
        e1?.city == e2?.city &&
        listEquality.equals(e1?.hobbies, e2?.hobbies) &&
        e1?.dreamRide == e2?.dreamRide &&
        listEquality.equals(e1?.favouriteTracks, e2?.favouriteTracks) &&
        listEquality.equals(e1?.futureMods, e2?.futureMods) &&
        listEquality.equals(e1?.followers, e2?.followers) &&
        listEquality.equals(e1?.following, e2?.following);
  }

  @override
  int hash(UserRecord? e) => const ListEquality().hash([
        e?.email,
        e?.displayName,
        e?.photoUrl,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.rides,
        e?.race,
        e?.sex,
        e?.relationshipstatus,
        e?.age,
        e?.religion,
        e?.dob,
        e?.city,
        e?.hobbies,
        e?.dreamRide,
        e?.favouriteTracks,
        e?.futureMods,
        e?.followers,
        e?.following
      ]);

  @override
  bool isValidKey(Object? o) => o is UserRecord;
}
