import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:async';
import 'dart:ui';
import 'edit_specification_widget.dart' show EditSpecificationWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class EditSpecificationModel extends FlutterFlowModel<EditSpecificationWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for year_make_model widget.
  FocusNode? yearMakeModelFocusNode1;
  TextEditingController? yearMakeModelTextController1;
  String? Function(BuildContext, String?)?
      yearMakeModelTextController1Validator;
  // State field(s) for year_make_model widget.
  FocusNode? yearMakeModelFocusNode2;
  TextEditingController? yearMakeModelTextController2;
  String? Function(BuildContext, String?)?
      yearMakeModelTextController2Validator;
  bool isDataUploading_uploadDataLxo = false;
  FFUploadedFile uploadedLocalFile_uploadDataLxo =
      FFUploadedFile(bytes: Uint8List.fromList([]));

  // State field(s) for modifications widget.
  FocusNode? modificationsFocusNode;
  TextEditingController? modificationsTextController;
  String? Function(BuildContext, String?)? modificationsTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    yearMakeModelFocusNode1?.dispose();
    yearMakeModelTextController1?.dispose();

    yearMakeModelFocusNode2?.dispose();
    yearMakeModelTextController2?.dispose();

    modificationsFocusNode?.dispose();
    modificationsTextController?.dispose();
  }
}
